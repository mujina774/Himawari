/* ----------------------------------------------------------------------------
    Sample source code for Himawari Standard Data or HRIT Data 

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of Himawari Standard Format:
  	For data structure of Himawari Standard Format, prelese refer to MSC
    	Website and Himawari Standard Data User's Guid.

    	MSC Website
    	https://www.data.jma.go.jp/mscweb/en/index.html

    	Himawari Standard Data User's Guid
    	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en.pdf


    Detail of HRIT data:
	Please visit the MSC web site and refer to the document,
        "JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

        MSC Website
	https://www.data.jma.go.jp/mscweb/en/index.html
	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

        Hrit data: 
	https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

    History
        June,   2015 First release
	June,   2021 Version 2021-06
		     Fixed bug in function  makeSataidHeader() function (sataid_utl.c)

---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include "sataid_utl.h"
# include "date_utl.h"

# define  NORMAL_END        0
# define  ERROR_ARG         1
# define  ERROR_FILE_OPEN   2
# define  ERROR_CALLOCATE   3
# define  ERROR_READ_HEADER 4
# define  ERROR_INFO        5
# define  ERROR_READ_DATA   6
# define  ERROR_PARAMETER   7
# define  ERROR_MAKE_HEADER 8
# define  ERROR_MAKE_DATA   9
# define  ERROR_WRITE       10

# define    RECLEN  256
# define    WIDTHLEN(i, j)  ((i+j-1)/j)

/* ----------------------------------------------------------------
 *
    read               | print               | write               
    ---------------------------------------------------------------
    readSataidHeader() | printSataidHeader() | writeSataidHeader()
    readSataidCalib()  | printSataidCalib()  | writeSataidCalib()
    readSataidData()   | printSataidData()   | writeSataidData()
    ---------------------------------------------------------------

    make               | make_1byte
    ---------------------------------------------------------------
    makeSataidHeader() | makeSataidHeader_1byte()
    makeSataidCalib()  | makeSataidCalib_1byte()
    makeSataidData()   | makeSataidData_1byte()
    ---------------------------------------------------------------
-----------------------------------------------------------------------------*/
static int sub_makeSataidCalib(outdata *data,GMSCTL *pctl,CALIB *calb,char step);

/* ---------------------------------------------------------------------------
  read Header block of SATAID data
 -----------------------------------------------------------------------------*/
int readSataidHeader(FILE *fp,GMSCTL *pctl){

    /* 1 control block */
    if(
        ( 0 != fseek(fp,0,SEEK_SET)       ) ||
        ( 1 != fread(&pctl->cntl0,4,1,fp) ) ||
        ( 8 != fread(&pctl->flid, 1,8,fp) ) ||
        ( 8 != fread(&pctl->stnm, 1,8,fp) ) ||
        ( 1 != fread(&pctl->chno, 4,1,fp) ) ||
        ( 8 != fread(&pctl->sttm, 4,8,fp) ) ||
        ( 8 != fread(&pctl->entm, 4,8,fp) ) ||
        ( 1 != fread(&pctl->coch, 4,1,fp) ) ||
        ( 1 != fread(&pctl->pix0, 4,1,fp) ) ||
        ( 1 != fread(&pctl->lin0, 4,1,fp) ) ||
        ( 1 != fread(&pctl->pxsz, 4,1,fp) ) ||
        ( 1 != fread(&pctl->lnsz, 4,1,fp) ) ||
        ( 1 != fread(&pctl->pix1, 4,1,fp) ) ||
        ( 1 != fread(&pctl->lin1, 4,1,fp) ) ||
        ( 1 != fread(&pctl->recs, 4,1,fp) ) ||
        ( 1 != fread(&pctl->btln, 4,1,fp) ) ||
        ( 1 != fread(&pctl->p[0].lat,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[0].lon,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[1].lat,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[1].lon,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[2].lat,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[2].lon,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[3].lat,4,1,fp) ) ||
        ( 1 != fread(&pctl->p[3].lon,4,1,fp) ) ||
        ( 1 != fread(&pctl->cals,4,1,fp) ) ||
        ( 1 != fread(&pctl->lvl0,4,1,fp) ) ||
        ( 1 != fread(&pctl->lvl1,4,1,fp) ) || 
        ( 0 != fseek(fp,192,SEEK_SET)    ) ||
        ( 1 != fread(&pctl->roll, 4,1,fp)) ||
        ( 1 != fread(&pctl->pitch,4,1,fp)) ||
        ( 1 != fread(&pctl->yaw,  4,1,fp)) ||
        ( 1 != fread(&pctl->slat, 4,1,fp)) ||
        ( 1 != fread(&pctl->slon, 4,1,fp)) ||
        ( 1 != fread(&pctl->sdst, 4,1,fp)) ||
        ( 0 != fseek(fp,248,SEEK_SET)    ) ||
        ( 1 != fread(&pctl->fver, 4,1,fp)) ||
        ( 1 != fread(&pctl->cntl1,4,1,fp))
    ){
        fprintf(stderr,"read control block error\n");
        return(ERROR_READ_HEADER);
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  read Calb table block of SATAID data
 -----------------------------------------------------------------------------*/
int readSataidCalib(FILE *fp,GMSCTL *pctl,CALIB *calb){
    int    calb_len;

    /* 2 calib table block */
    if( 0 != fseek(fp,pctl->cntl1,SEEK_SET)){
        fprintf(stderr,"read control block error\n");
        return(ERROR_READ_HEADER);
    }
    if( 1 != fread(&calb->cntl_c0,4,1,fp)){
        fprintf(stderr,"read control block error\n");
        return(ERROR_READ_HEADER);
    }
    calb_len = (calb->cntl_c0/4)-2;
    if(NULL == ( calb->calb_table = (float *)calloc(calb_len,sizeof(float)))){
        fprintf(stderr,"callocate error\n");
        return(ERROR_CALLOCATE);
    }
    if( (calb_len != fread(&calb->calb_table[0],4,calb_len,fp) ) ||
        (1        != fread(&calb->cntl_c1,4,1,fp)) ){
        fprintf(stderr,"read control block error\n");
        return(ERROR_READ_HEADER);
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  read data block of SATAID data
 -----------------------------------------------------------------------------*/
int readSataidData(FILE *fp,GMSCTL *pctl,CALIB *calb,DATA_BLOCK *data_block){

    int ii;
    int seek_pt;
    int data_num;

    /* 3 data block */
    if(pctl->btln == 1){
    // 1 byte
        data_block->cntl_d0 = (int *) calloc(pctl->lin1,sizeof(int));
        data_block->cntl_d1 = (int *) calloc(pctl->lin1,sizeof(int));
        data_block->data_char  = (unsigned char **)
            calloc(pctl->lin1,sizeof(unsigned char *));
        if( NULL == data_block->cntl_d0 || NULL == data_block->cntl_d1 ||
            NULL == data_block->data_char){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
        for(ii=0;ii<pctl->lin1;ii++){
            seek_pt = (pctl->cntl1 + calb->cntl_c0) + (data_block->cntl_d0[0] * ii);
            fseek(fp,seek_pt,SEEK_SET);
            if( 1 != fread(&data_block->cntl_d0[ii],4,1,fp)){
                fprintf(stderr,"read calb table block error\n");
                return(ERROR_READ_DATA);
            }
            data_num = (data_block->cntl_d0[ii] - 4 * 2) / sizeof(unsigned char);
            data_block->data_char[ii] = (unsigned char *)
                calloc(data_num,sizeof(unsigned char));
            if(NULL == data_block->data_char[ii]){
                fprintf(stderr,"callocate error\n");
                return(ERROR_CALLOCATE);
            }
            if(
            ( data_num != fread(&data_block->data_char[ii][0],1,data_num,fp)) ||
            ( 1        != fread(&data_block->cntl_d1[ii],4,1,fp)) ){
                fprintf(stderr,"read calb table block error\n");
                return(ERROR_READ_DATA);
            }
        }
    }else{
    // 2 byte
        data_block->cntl_d0 = (int *) calloc(pctl->lin1,sizeof(int));
        data_block->cntl_d1 = (int *) calloc(pctl->lin1,sizeof(int));
        data_block->data_value = (unsigned short **)
            calloc(pctl->lin1,sizeof(unsigned short *));
        if( NULL == data_block->cntl_d0 || NULL == data_block->cntl_d1 ||
            NULL == data_block->data_value){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
        for(ii=0;ii<pctl->lin1;ii++){
            seek_pt = (pctl->cntl1 + calb->cntl_c0) + (data_block->cntl_d0[0] * ii);
            fseek(fp,seek_pt,SEEK_SET);
            if( 1 != fread(&data_block->cntl_d0[ii],4,1,fp)){
                fprintf(stderr,"read calb table block error\n");
                return(ERROR_READ_DATA);
            }
            data_num = (data_block->cntl_d0[ii] - 4 * 2) / sizeof(unsigned short);
            data_block->data_value[ii] = (unsigned short *)
                calloc(data_num,sizeof(unsigned short));
            if(NULL == data_block->data_value[ii]){
                fprintf(stderr,"callocate error\n");
                return(ERROR_CALLOCATE);
            }
            if(
            ( data_num != fread(&data_block->data_value[ii][0],2,data_num,fp)) ||
            ( 1        != fread(&data_block->cntl_d1[ii],4,1,fp)) ){
                fprintf(stderr,"read calb table block error\n");
                return(ERROR_READ_DATA);
            }
        }
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  print Header block of SATAID data
 -----------------------------------------------------------------------------*/
void printSataidHeader(GMSCTL *pctl){

    printf("#--------------------------------------------\n");
    printf("# control block\n");
    printf("#  1-  4 record length  = %d\n",pctl->cntl0);
    printf("#  5- 12 sensor name    = %s\n",pctl->flid);
    printf("# 13- 20 satellit name  = %s\n",pctl->stnm);
    printf("# 21- 24 channel number = %d\n",pctl->chno);
    printf("# 25- 28 year           = %d\n",pctl->sttm[0]);
    printf("# 29- 32 year           = %d\n",pctl->sttm[1]);
    printf("# 33- 36 month          = %d\n",pctl->sttm[2]);
    printf("# 37- 40 day            = %d\n",pctl->sttm[3]);
    printf("# 41- 44 hour           = %d\n",pctl->sttm[4]);
    printf("# 45- 48 minute         = %d\n",pctl->sttm[5]);
    printf("# 49- 52 second         = %d\n",pctl->sttm[6]);
    printf("# 53- 56 micro second   = %d\n",pctl->sttm[7]);
    printf("# 57- 60 year           = %d\n",pctl->entm[0]);
    printf("# 61- 64 year           = %d\n",pctl->entm[1]);
    printf("# 65- 68 month          = %d\n",pctl->entm[2]);
    printf("# 69- 72 day            = %d\n",pctl->entm[3]);
    printf("# 73- 76 hour           = %d\n",pctl->entm[4]);
    printf("# 77- 80 minute         = %d\n",pctl->entm[5]);
    printf("# 81- 84 second         = %d\n",pctl->entm[6]);
    printf("# 85- 88 micro second   = %d\n",pctl->entm[7]);
    printf("# 89- 92 coch           = %d\n",pctl->coch);
    printf("# 93- 96 pixel          = %d\n",pctl->pix0);
    printf("# 97-100 line           = %d\n",pctl->lin0);
    printf("#101-104 dlon           = %f\n",pctl->pxsz);
    printf("#105-108 dlat           = %f\n",pctl->lnsz);
    printf("#109-112 pixel          = %d\n",pctl->pix1);
    printf("#113-116 line           = %d\n",pctl->lin1);
    printf("#117-120 record         = %d\n",pctl->recs);
    printf("#121-124 byte           = %d\n",pctl->btln);
    printf("#125-128 left  top lat  = %f\n",pctl->p[0].lat);
    printf("#129-132           lon  = %f\n",pctl->p[0].lon);
    printf("#133-136 right top lat  = %f\n",pctl->p[1].lat);
    printf("#137-140           lon  = %f\n",pctl->p[1].lon);
    printf("#141-144 left  bot lat  = %f\n",pctl->p[2].lat);
    printf("#145-148           lon  = %f\n",pctl->p[2].lon);
    printf("#149-152 right bot lat  = %f\n",pctl->p[3].lat);
    printf("#153-156           lon  = %f\n",pctl->p[3].lon);
    printf("#157-160 nLevel         = %d\n",pctl->cals);
    printf("#160-164 lowest levels  = %d\n",pctl->lvl0);
    printf("#165-168 highest levels = %d\n",pctl->lvl1);
    printf("#169-192\n");
    printf("#193-196 roll           = %f\n",pctl->roll);
    printf("#197-200 pitch          = %f\n",pctl->pitch);
    printf("#201-204 yaw            = %f\n",pctl->yaw);
    printf("#205-208 ssp lat        = %f\n",pctl->slat);
    printf("#209-212 ssp lon        = %f\n",pctl->slon);
    printf("#213-216 distance       = %f\n",pctl->sdst);
    printf("#249-252 version        = %s\n",pctl->fver);
    printf("#253-256 record length  = %d\n",pctl->cntl1);
}
/* ---------------------------------------------------------------------------
  print Calb table block of SATAID data
 -----------------------------------------------------------------------------*/
void printSataidCalib(CALIB *calb){
    int ii;

    printf("#--------------------------------------------\n");
    printf("#calbib table block\n");
    printf("#  1-  4 calb length  = %d\n",calb->cntl_c0);
    printf("#  5-    calb table\n");
    for(ii=0;ii<(calb->cntl_c0/4)-2;ii++){
        if(ii % 10 == 0){
            printf("# %5.2f",calb->calb_table[ii]);
        }else if(ii % 10 == 9){
            printf(" %5.2f\n",calb->calb_table[ii]);
        }else{
            printf(" %5.2f",calb->calb_table[ii]);
        }
    }
    printf("\n");
    printf("# %d-%d   calb length  = %d\n",
        calb->cntl_c1-4,calb->cntl_c1,calb->cntl_c1);
}
/* ---------------------------------------------------------------------------
  print Data block of SATAID data
 -----------------------------------------------------------------------------*/
void printSataidData(GMSCTL *pctl,DATA_BLOCK *data_block){
    int ii,jj;
    int data_num;

    printf("#--------------------------------------------\n");
    printf("# data block\n");
    if(pctl->btln == 1){
    // 1 byte
        data_num = (data_block->cntl_d0[0] - 4 * 2);
        for(ii=0;ii<pctl->lin1;ii=ii+pctl->lin1/8){
            printf("%d | ",data_block->cntl_d0[ii]);
            for(jj=0;jj<data_num;jj=jj+data_num/8){
                printf(" %6d",data_block->data_char[ii][jj]);
            }
            printf(" | %d\n",data_block->cntl_d1[ii]);
        }
    }else{
    // 2 byte
        data_num = (data_block->cntl_d0[0] - 4 * 2) / 2;
        for(ii=0;ii<pctl->lin1;ii=ii+pctl->lin1/8){
            printf("%d | ",data_block->cntl_d0[ii]);
            for(jj=0;jj<data_num;jj=jj+data_num/8){
                printf(" %6d",data_block->data_value[ii][jj]);
            }
            printf(" | %d\n",data_block->cntl_d1[ii]);
        }
    }
}

/* ---------------------------------------------------------------------------
  write SatAid Header
 -----------------------------------------------------------------------------*/
int writeSataidHeader(FILE *fp,GMSCTL *pctl){
    if(
        ( 1 != fwrite(&pctl->cntl0,4,1,fp) ) || 
        ( 8 != fwrite(&pctl->flid ,1,8,fp) ) ||
        ( 8 != fwrite(&pctl->stnm ,1,8,fp) ) || 
        ( 1 != fwrite(&pctl->chno ,4,1,fp) ) ||
        ( 8 != fwrite(&pctl->sttm,4,8,fp) ) ||
        ( 8 != fwrite(&pctl->entm,4,8,fp) ) ||
        ( 1 != fwrite(&pctl->coch,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->pix0,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->lin0,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->pxsz,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->lnsz,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->pix1,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->lin1,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->recs,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->btln,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[0].lat,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[0].lon,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[1].lat,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[1].lon,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[2].lat,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[2].lon,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[3].lat,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->p[3].lon,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->cals,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->lvl0,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->lvl1,4,1,fp) ) ||
        ( 6 != fwrite(&pctl->dumm0,4,6,fp) ) ||
        ( 1 != fwrite(&pctl->roll,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->pitch,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->yaw,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->slat,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->slon,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->sdst,4,1,fp) ) ||
        ( 8 != fwrite(&pctl->dumm1,4,8,fp) ) ||
        ( 1 != fwrite(&pctl->fver,4,1,fp) ) ||
        ( 1 != fwrite(&pctl->cntl1,4,1,fp) )
    ){
        fprintf(stderr,"write error\n");
        return(ERROR_WRITE);
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  write SatAid Calib
 -----------------------------------------------------------------------------*/
int writeSataidCalib(FILE *fp,CALIB *calb){
    int    calb_len;

    /* 2 calib table block */
    calb_len = (calb->cntl_c0/4)-2;
    if(
        ( calb_len < 0 ) || 
        ( 1        != fwrite(&calb->cntl_c0,4,1,fp)          ) ||
        ( calb_len != fwrite(calb->calb_table,4,calb_len,fp) ) ||
        ( 1        != fwrite(&calb->cntl_c1,4,1,fp)          )
    ){
        fprintf(stderr,"write error\n");
        return(ERROR_WRITE);
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  write SatAid Data
 -----------------------------------------------------------------------------*/
int writeSataidData(FILE *fp,GMSCTL *pctl,DATA_BLOCK *data_block){
    int ii;
    int data_num;

    /* 3 data block */
    if(pctl->btln == 1){
    // 1 byte
        for(ii=0;ii<pctl->lin1;ii++){
            data_num = (data_block->cntl_d0[ii] - 4 * 2) ;
            if(
            ( 1        != fwrite(&data_block->cntl_d0[ii],4,1,fp)              ) ||
            ( data_num != fwrite(&data_block->data_char[ii][0],1,data_num,fp)  ) ||
            ( 1        != fwrite(&data_block->cntl_d1[ii],4,1,fp)              )
            ){
                fprintf(stderr,"write error\n");
                return(ERROR_WRITE);
            }
        }
    }else{
    // 2 byte
        for(ii=0;ii<pctl->lin1;ii++){
            data_num = (data_block->cntl_d0[ii] - 4 * 2) / 2;
            if(
            ( 1        != fwrite(&data_block->cntl_d0[ii],4,1,fp)              ) ||
            ( data_num != fwrite(&data_block->data_value[ii][0],2,data_num,fp) ) ||
            ( 1        != fwrite(&data_block->cntl_d1[ii],4,1,fp)              )
            ){
                fprintf(stderr,"write error\n");
                return(ERROR_WRITE);
            }
        }
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  make header of Sataid data
 -----------------------------------------------------------------------------*/
int makeSataidHeader(parameter *param,outdata *data,GMSCTL *pctl){
                    //   12345678
    char name[16][8] = {"V1", "V2", "VS", "N1", 
                        "N2", "N3", "I4", "WV", 
                        "W2", "W3", "MI", "O3", 
                        "IR", "L2", "I2", "CO" };
    int date[7];
    int nLevel = 1 << data->nBit;

    //   1-  4   bytes of block
    pctl->cntl0 = RECLEN;    
    //   5- 12   kind of image eg:GMS-IR, GMS-VIS
    strcpy(pctl->flid,name[param->band -1]);
    //  13- 20   sattelite name eg:GMS-4
    
    if(!strcmp(data->satName,"Himawari-8")){
        strcpy(pctl->stnm,"Himawa-8");
    }else if(!strcmp(data->satName,"Himawari-9")){
        strcpy(pctl->stnm,"Himawa-9");
    }else if(!strcmp(data->satName,"Himawari")){ /* 2021.06 added */
        strcpy(pctl->stnm,data->satName);
    }else if(!strcmp(data->satName,"MTSAT-2")){
		strcpy(pctl->stnm,"MTSAT");
	}
    //  21- 24   number of channel
    pctl->chno = 0;
    //  25- 56   start time of data
    mjd_to_date(data->startTime,date);
    pctl->sttm[0] = date[0] / 100;
    pctl->sttm[1] = date[0] % 100;
    pctl->sttm[2] = date[1];
    pctl->sttm[3] = date[2];
    pctl->sttm[4] = date[3];
    pctl->sttm[5] = date[4];
    pctl->sttm[6] = date[5];
    pctl->sttm[7] = date[6];
    //  57- 88   end time of data
    mjd_to_date(data->endTime,date);
    pctl->entm[0] = date[0] / 100;
    pctl->entm[1] = date[0] % 100;
    pctl->entm[2] = date[1];
    pctl->entm[3] = date[2];
    pctl->entm[4] = date[3];
    pctl->entm[5] = date[4];
    pctl->entm[6] = date[5];
    pctl->entm[7] = date[6];
    //  89- 92   flag of cordinate change TRUE/FALSE
    pctl->coch = 1;        // true
    //  93-100   pixel and line number before cordinate change
    pctl->pix0 = data->pix0;
    pctl->lin0 = data->lin0;
    // 101-108   resolution of pixel and line
    pctl->pxsz = param->dlon;
    pctl->lnsz = param->dlat;
    // 109-116   pixel and line number after change
    pctl->pix1 = param->width;
    pctl->lin1 = param->height;
    // 117-124   record per line and byte per pixel
//    pctl->btln = (nLevel > RECLEN)? 2 : 1;
    pctl->btln = 2;
    pctl->recs = WIDTHLEN(param->width * pctl->btln + 2 * sizeof(int), RECLEN);
    // 125-156   lat. and long. of corner of image (deg.)
    pctl->p[0].lon = pctl->p[2].lon = (float)(data->lon[0]);
    pctl->p[1].lon = pctl->p[3].lon = (float)(data->lon[param->width-1]);
    pctl->p[0].lat = pctl->p[1].lat = (float)(data->lat[0]);
    pctl->p[2].lat = pctl->p[3].lat = (float)(data->lat[param->height-1]);
    // 157-160   calibration number
    pctl->cals = nLevel -2;
    // 161-168   lowest and highest levels of calibration
    pctl->lvl0 = 1;
    pctl->lvl1 = nLevel -2;
    // 193-204   attitude of satellite (deg.)
    pctl->roll  = 0.0;    // dummy value
    pctl->pitch = 0.0;    // dummy value
    pctl->yaw   = 0.0;    // dummy value
    // 205-216   position of satellite (deg./R+h:m)
    pctl->slat  = data->slat;
    pctl->slon  = data->slon;
    pctl->sdst  = data->sdst;
    // 249-252   file version eg:1.1
    sprintf(pctl->fver,"1.1");
    // 253-256   bytes of block
    pctl->cntl1 = RECLEN;

    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  make header of Sataid data ( 1 byte )
 -----------------------------------------------------------------------------*/
int makeSataidHeader_1byte(parameter *param,outdata *data,GMSCTL *pctl){
    int nLevel = 256;  // 1 byte ( = 8 bit )

    if(NORMAL_END != makeSataidHeader(param,data,pctl)){
        return(ERROR_MAKE_HEADER);
    }
    // for 1 byte sataid data
    // 117-124   record per line and byte per pixel
    pctl->btln = 1;    // 1 byte
    pctl->recs = WIDTHLEN(param->width * pctl->btln + 2 * sizeof(unsigned char), RECLEN);
    // 157-160   calibration number
    pctl->cals = nLevel -2;
    // 161-168   lowest and highest levels of calibration
    pctl->lvl0 = 1;
    pctl->lvl1 = nLevel -2;
    // 253-256   bytes of block
    pctl->cntl1 = RECLEN;
    //
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  make calib table of Sataid data ( 2 byte )
 -----------------------------------------------------------------------------*/
int makeSataidCalib(outdata *data,GMSCTL *pctl,CALIB *calb){
    char step;
    step = 1;
    if(NORMAL_END != sub_makeSataidCalib(data,pctl,calb,step)){
        return(ERROR_MAKE_HEADER);
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  make calib table of Sataid data ( 1 byte )
 -----------------------------------------------------------------------------*/
int makeSataidCalib_1byte(outdata *data,GMSCTL *pctl,CALIB *calb){
    char step;
    step = 1 << (data->nBit - 8);
    if(NORMAL_END != sub_makeSataidCalib(data,pctl,calb,step)){
        return(ERROR_MAKE_HEADER);
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  make calib table of Sataid data 
 -----------------------------------------------------------------------------*/
static int sub_makeSataidCalib(outdata *data,GMSCTL *pctl,CALIB *calb,char step){
    int calb_len;
    int ii;    

    calb_len = (pctl->lvl1 - pctl->lvl0 + 1);
    calb->cntl_c0 = (calb_len + 2) * 4;
    calb->cntl_c1 = (calb_len + 2) * 4;
    calb->calb_table = (float *)calloc(calb_len,sizeof(float));
    if(NULL == calb->calb_table){
        fprintf(stderr,"callocate error\n");
        return(ERROR_CALLOCATE);
    }
    for(ii=0;ii<calb_len;ii++){
        calb->calb_table[ii] = data->fVal[ii*step];
    }
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  make Data block of Sataid data
 -----------------------------------------------------------------------------*/
int makeSataidData(parameter *param,outdata *data,GMSCTL *pctl,CALIB *calb,
    DATA_BLOCK *data_block){
    int data_num;
    int ii,jj;
    int kk,nn;
    int n0,n1,nc;
    unsigned short nBit = data->nBit;

    data_num = pctl->recs * RECLEN / 2  ;

    data_block->cntl_d0 = (int *) calloc(pctl->lin1,sizeof(int));
    data_block->cntl_d1 = (int *) calloc(pctl->lin1,sizeof(int));
    data_block->data_value = (unsigned short **)calloc(pctl->lin1,sizeof(unsigned short *));

    if( NULL == data_block->cntl_d0 || NULL == data_block->cntl_d1 ||
        NULL == data_block->data_value){
        fprintf(stderr,"callocate error\n");
        return(ERROR_CALLOCATE);
    }

    for(ii=0;ii<pctl->lin1;ii++){
        data_block->cntl_d0[ii] = pctl->recs * RECLEN;
        data_block->cntl_d1[ii] = pctl->recs * RECLEN;
        data_block->data_value[ii] = (unsigned short *)calloc(data_num,sizeof(unsigned short));
        if(NULL == data_block->data_value[ii]){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
    }
    if(param->band <  7){
        // visible band, near infra-red band
        for(ii=0;ii<pctl->lin1;ii++){
        for(jj=0;jj<pctl->pix1;jj++){
            kk = ii * param->width + jj;
            n0 = pctl->lvl0;  n1 = pctl->lvl1 - 1; nc = (n0 + n1) /2;
            if(data->phys[kk] > calb->calb_table[pctl->lvl1-1]){
                data_block->data_value[ii][jj] = n1;
            }else if(data->phys[kk] < calb->calb_table[pctl->lvl0]){
                data_block->data_value[ii][jj] = n0;
            }else{
                n0 = pctl->lvl0;  n1 = pctl->lvl1; nc = (n0 + n1) /2;
                for(nn=0;nn<nBit+1;nn++){
                    if(data->phys[kk] > calb->calb_table[nc]) n0 = nc;
                    else                                      n1 = nc;
                    nc = (n0 + n1) /2;
                    if(n1-n0==1){
                        data_block->data_value[ii][jj] = nc;
                        break;
                    }
                }
            }
        }
        }
    }else{
        // infra-red band
        for(ii=0;ii<pctl->lin1;ii++){
        for(jj=0;jj<pctl->pix1;jj++){
            kk = ii * param->width + jj;
            n0 = pctl->lvl0;  n1 = pctl->lvl1 - 1; nc = (n0 + n1) /2;
            if(data->phys[kk] < calb->calb_table[pctl->lvl1-1]){
                data_block->data_value[ii][jj] = n1;
            }else if(data->phys[kk] > calb->calb_table[pctl->lvl0]){
                data_block->data_value[ii][jj] = n0;
            }else{
                n0 = pctl->lvl0;  n1 = pctl->lvl1; nc = (n0 + n1) /2;
                for(nn=0;nn<nBit+1;nn++){
                    if(data->phys[kk] < calb->calb_table[nc]) n0 = nc;
                    else                                      n1 = nc;
                    nc = (n0 + n1) /2;
                    if(n1-n0==1){
                        data_block->data_value[ii][jj] = nc;
                        break;
                    }
                }
            }
        }
        }
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  make Data block of Sataid data ( 1 byte )
 -----------------------------------------------------------------------------*/
int makeSataidData_1byte(parameter *param,outdata *data,GMSCTL *pctl,CALIB *calb,
    DATA_BLOCK *data_block){
    int data_num;
    int ii,jj;
    int kk,nn;
    int n0,n1,nc;
    unsigned short nBit = 8;

    data_num = pctl->recs * RECLEN   ;

    data_block->cntl_d0 = (int *) calloc(pctl->lin1,sizeof(int));
    data_block->cntl_d1 = (int *) calloc(pctl->lin1,sizeof(int));
    data_block->data_char = (unsigned char  **)calloc(pctl->lin1,sizeof(unsigned char *));

    if( NULL == data_block->cntl_d0 || NULL == data_block->cntl_d1 ||
        NULL == data_block->data_char){
        fprintf(stderr,"callocate error\n");
        return(ERROR_CALLOCATE);
    }

    for(ii=0;ii<pctl->lin1;ii++){
        data_block->cntl_d0[ii] = pctl->recs * RECLEN;
        data_block->cntl_d1[ii] = pctl->recs * RECLEN;
        data_block->data_char[ii] = (unsigned char *)calloc(data_num,sizeof(unsigned char));
        if(NULL == data_block->data_char[ii]){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
    }

    if(param->band <  7){
        // visible band, near infra-red band
        for(ii=0;ii<pctl->lin1;ii++){
        for(jj=0;jj<pctl->pix1;jj++){
            kk = ii * param->width + jj;
            n0 = pctl->lvl0;  n1 = pctl->lvl1 - 1; nc = (n0 + n1) /2;
            if(data->phys[kk] > calb->calb_table[pctl->lvl1-1]){
                data_block->data_char [ii][jj] = n1;
            }else if(data->phys[kk] < calb->calb_table[pctl->lvl0]){
                data_block->data_char [ii][jj] = n0;
            }else{
                n0 = pctl->lvl0;  n1 = pctl->lvl1; nc = (n0 + n1) /2;
                for(nn=0;nn<nBit+1;nn++){
                    if(data->phys[kk] > calb->calb_table[nc]) n0 = nc;
                    else                                      n1 = nc;
                    nc = (n0 + n1) /2;
                    if(n1-n0==1){
                        data_block->data_char [ii][jj] = nc;
                        break;
                    }
                }
            }
        }
        }
    }else{
        // infra-red band
        for(ii=0;ii<pctl->lin1;ii++){
        for(jj=0;jj<pctl->pix1;jj++){
            kk = ii * param->width + jj;
            n0 = pctl->lvl0;  n1 = pctl->lvl1 - 1; nc = (n0 + n1) /2;
            if(data->phys[kk] < calb->calb_table[pctl->lvl1-1]){
                data_block->data_char [ii][jj] = n1;
            }else if(data->phys[kk] > calb->calb_table[pctl->lvl0]){
                data_block->data_char [ii][jj] = n0;
            }else{
                n0 = pctl->lvl0;  n1 = pctl->lvl1; nc = (n0 + n1) /2;
                for(nn=0;nn<nBit+1;nn++){
                    if(data->phys[kk] < calb->calb_table[nc]) n0 = nc;
                    else                                      n1 = nc;
                    nc = (n0 + n1) /2;
                    if(n1-n0==1){
                        data_block->data_char [ii][jj] = nc;
                        break;
                    }
                }
            }
        }
        }
    }
    return(NORMAL_END);
}
