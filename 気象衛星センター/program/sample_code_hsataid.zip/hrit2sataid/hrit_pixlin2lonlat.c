/* ----------------------------------------------------------------------------
    Sample source code for HRIT Data

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of HRIT data:
	Please visit the MSC web site and refer to the document,
        "JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

        MSC website:
        https://www.data.jma.go.jp/mscweb/en/index.html
        https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

        HRIT data:
        https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

    History
        June,    2015  First release

   ---------------------------------------------------------------------------- */


#include <stdio.h>
#include <math.h>
#include "hrit.h"

#define SP_HRIT_OUTAREA 1
#define SP_HRIT_SCLUNIT 1.525878906250000e-05 /* 2^-16 */
#define SP_CONST_RADTODEG (180.0/M_PI)
#define SP_CONST_DEGTORAD (M_PI/180.0)


// for MTSAT-1R,2
#define SP_HRIT_PLR 6356.5838 
#define SP_HRIT_EQR 6378.1690
#define SP_HRIT_SATR 42164.0
#define SP_HRIT_FLAT (1.0-SP_HRIT_PLR / SP_HRIT_EQR)
#define SP_HRIT_PARAM1 0.00675701

// for Himawari-8,9
#define SP_HRIT_PLR_Himawari 6356.7523 
#define SP_HRIT_EQR_Himawari 6378.1370
#define SP_HRIT_SATR_Himawari 42164.0
#define SP_HRIT_FLAT_Himawari (1.0-SP_HRIT_PLR_Himawari / SP_HRIT_EQR_Himawari)
#define SP_HRIT_PARAM1_Himawari 0.00669438444

#define SP_NAV_NORMAL        0
#define SP_NAV_ERR_LAT       1
#define SP_NAV_ERR_PARAM     2
#define SP_NAV_ERR_FRAMELIN  4
#define SP_NAV_ERR_FRAMEPIX  8
#define SP_NAV_ERR_SIDE     16
#define SP_NAV_ERR_UNKNOWN  32

#define SP_NAV_OUTAREA    -9999

int lonlat_to_pixlin(SpHritFile *info,double lon,double lat,
    float *pix,float *lin,int flag) {

	double phi;		/* Geocentric Latitude */
	double sinPhi,cosPhi;
	double localR;	/* Radius */
	double pXYZ[3];	/* EF */
	double view[3];	/* Vector : Sat -> Point */
	double ix,iy;
	float cc,ll;	/* HRIT(line,column) */

	double Rpol = SP_HRIT_PLR;
	double flat = SP_HRIT_FLAT;
	double param1 = SP_HRIT_PARAM1;

	// (0) satellite
	if(flag == 1){  // WGS84
		Rpol = SP_HRIT_PLR_Himawari;
		flat = SP_HRIT_FLAT_Himawari;
		param1 = SP_HRIT_PARAM1_Himawari;
	}
    // (1) init
    *pix = SP_NAV_OUTAREA;
    *lin = SP_NAV_OUTAREA;
    // (2) check latitude
	if( lat<-90.0 || 90.0<lat ) {
		return(SP_NAV_ERR_LAT);
	}
    // (3) check longitude
	while(lon >  180) { lon-=360; } // [deg]
	while(lon < -180) { lon+=360; } // [deg]
	// (4) degree to radian
	lon = lon * SP_CONST_DEGTORAD;
	lat = lat * SP_CONST_DEGTORAD;
	// (5) geocentric latitude
	// Global Specification 4.4.3.2
	phi=atan((1.0 - flat)*(1.0 - flat)*tan(lat));
	sinPhi=sin(phi);
	cosPhi=sqrt(1-sinPhi*sinPhi);
	// (6) The length of Re
	localR = Rpol /(sqrt(1.0 - param1 * cosPhi * cosPhi));
	// (7) The cartesian components of the vector rs
	pXYZ[0]=localR*cosPhi*cos(lon-info->proj->subLon*SP_CONST_DEGTORAD);
	pXYZ[1]=localR*cosPhi*sin(lon-info->proj->subLon*SP_CONST_DEGTORAD);
	pXYZ[2]=localR*sinPhi;
	// (8) check the reverse side of the Earth
	view[0]=SP_HRIT_SATR-pXYZ[0];
	view[1]=-pXYZ[1];
	view[2]=pXYZ[2];
	// (8) check the reverse side of the Earth
	if(0<(-view[0]*pXYZ[0]-view[1]*pXYZ[1]+view[2]*pXYZ[2])) {
		return(SP_NAV_ERR_SIDE);
	}
	// (9) The projection function
	ix=-atan2(view[1],view[0])*SP_CONST_RADTODEG;
	iy=asin(-view[2]/sqrt(view[0]*view[0]+view[1]*view[1]+view[2]*view[2]))*SP_CONST_RADTODEG;
	// (10)
	// Global Specification 4.4.4
	cc=info->nav->coff+ix*SP_HRIT_SCLUNIT*info->nav->cfac;
	ll=info->nav->loff+iy*SP_HRIT_SCLUNIT*info->nav->lfac;

	/* (line,pixel) */
	*pix=cc;
	*lin=ll;

	return(SP_NAV_NORMAL);
	}
