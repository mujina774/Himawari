/* ----------------------------------------------------------------------------
    Sample source code for HRIT Data

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of HRIT data:
	Please visit the MSC web site and refer to the document,
        "JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

        MSC website:
	https://www.data.jma.go.jp/mscweb/en/index.html
        https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

        HRIT data:
        https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

    History
        June,    2015  First release
	June,	 2021  Version 2021-06
		       Fixed bug in function  getData() function (main.c)

   ---------------------------------------------------------------------------- */


# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hrit2sataid.h"
# include "sataid_utl.h"
# include "date_utl.h"
# include "hrit.h"

# define  MAXFILE   10
# define  INVALID   -1

# define  WIDTH     501 /* default pixel number */
# define  HEIGHT    501 /* default line number */
# define  LTLON    120.0    /* default left top longitude */
# define  LTLAT     50.0    /* default left top latitude */
# define  DLON      0.06    /* default Spatial resolution (longitude) */
# define  DLAT      0.06    /* default Spatial resolution (latitude) */

# define    RECLEN  256
# define    WIDTHLEN(i, j)  ((i+j-1)/j)

typedef struct{
    char    *InFile[MAXFILE+1];
    char    *OutFile;
    char    filenum;
}argument;

/* ------------------------------------------------------------------------- */
int getArg(int argc, char **argv, argument *arg,parameter *param);
int getData(argument *arg,parameter *param,outdata *data);
/* ---------------------------------------------------------------------------
  getArg()
 -----------------------------------------------------------------------------*/
int getArg(int argc, char **argv, argument *arg,parameter *param){
    char    *ptr;
    int     ii,nn=0;
    /* 1 init */
    arg->OutFile = NULL;
    for(ii=0;ii<MAXFILE;ii++){
        arg->InFile[ii] = NULL;
    }
    param->ltlat = LTLAT;   /* left top longitude */
    param->ltlon = LTLON;   /* left top longitude */
    param->width = WIDTH;   /* pixel number  */
    param->height= HEIGHT;  /* line number  */
    param->dlon  = DLON;    /* Spatial resolution (longitude) */
    param->dlat  = DLAT;    /* Spatial resolution (latitude) */
	param->byte  = 2;
    /* 2 get arguments */
    for(ii=1;ii<argc-1;ii++){
        ptr=argv[ii];
        if(*ptr=='-'){
            ptr++;
            switch (*ptr){
                case 'o':   /* output file */
                    arg->OutFile = argv[ii+1];
                    ii++;
                    break;
                case 'i':   /* input file */
                    if(nn<MAXFILE){
                        arg->InFile[nn] = argv[ii+1];
                        nn++;
                    }else{
                        fprintf(stderr,"InFile : %s [%d/%d]\n",
                            argv[ii+1],nn,MAXFILE);
                    }
                    ii++;
                    break;
                case 'd':
                case 'l':
                case 'w':
                case 'h':
                case 'b':
                    if(!strcmp(ptr,"lon")){
                        param->ltlon = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"lat")){
                        param->ltlat = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"width")){
                        param->width = atoi(argv[ii+1]);
                    }else if(!strcmp(ptr,"height")){
                        param->height = atoi(argv[ii+1]);
                    }else if(!strcmp(ptr,"dlon")){
                        param->dlon = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"dlat")){
                        param->dlat = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"byte")){
                        param->byte = atoi(argv[ii+1]);
                    }
                    ii++;
                    break;
            }
        }
    }
    arg->filenum = nn;
    /* 4 check parameter */
    if(param->width < 10){param->width =10;}
    if(param->height< 10){param->height=10;}
    if(param->ltlat < -90.  || 90.< param->ltlat){ param->ltlat = LTLAT;}
    if(param->ltlon <-180.  ||180.< param->ltlon){ param->ltlon = LTLON;}
    if(param->dlat  < 0. || 10. < param->dlat ){param->dlat = DLAT;}
    if(param->dlon  < 0. || 10. < param->dlon ){param->dlon = DLON;}
    /* 4 check error */
    if(arg->InFile[0]==NULL || arg->OutFile==NULL){
        return(ERROR_ARG);
    }
    /* 5 return */
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
   getData()
 -----------------------------------------------------------------------------*/
int getData(argument *arg,parameter *param,outdata *data){
    SpHritFile        **header;
    float            *Pix,*Lin;
    unsigned short  *startLine;
    unsigned short  *endLine;
    unsigned int    ii,jj,kk,ll;
    int             n;
    unsigned short  count;
    unsigned long   n_size = param->height * param->width;
    char            wgs84;
    float           minLine = 99999.0;
    float           maxLine =-99999.0;
    int             pix0,pix1;

    /* 1 allocate */
    header = (SpHritFile **)calloc(arg->filenum,sizeof(SpHritFile *));
    startLine = (unsigned short *)calloc(arg->filenum,sizeof(unsigned short *));
    endLine   = (unsigned short *)calloc(arg->filenum,sizeof(unsigned short *));
    Pix = (float *)calloc(n_size,sizeof(float *));
    Lin = (float *)calloc(n_size,sizeof(float *));

    /* 2 each file */
    n=-1;
    for(ii=0;ii<arg->filenum;ii++){
        /* 2-1 open file */
        /* 2-2 callocate */
        if(NULL == (header[ii] = (SpHritFile *)calloc(1,sizeof(SpHritFile)))){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
        /* 2-3 read hrit header */
        //spHritOpenFile(header[ii],arg->InFile[ii]);
        hrit_read_header(header[ii],arg->InFile[ii]);
        /* 2-4 starLine and endLine */
        startLine[ii] = header[ii]->startLineNo;
        endLine[ii]   = header[ii]->endLineNo;
        /* 2-5 check header consistency */
        if(n==-1)n=ii;
        if( header[n]->ch              != header[ii]->ch              ||
            header[n]->prim->typeCode  != header[ii]->prim->typeCode  ||
            header[n]->str->bitPix     != header[ii]->str->bitPix     ||
            header[n]->nav->coff       != header[ii]->nav->coff       ||
            header[n]->nav->loff       != header[ii]->nav->loff       ||
            header[n]->seg->totalSegNo != header[ii]->seg->totalSegNo ){
            fprintf(stderr,"header consistency error\n");
            fprintf(stderr,"%s : %s\n",arg->InFile[n],arg->InFile[ii]);
            return(ERROR_INFO);
        }
        n=ii;
    }
    /* 2-6 check file open */
    if(n==-1){
        fprintf(stderr,"error : can not open all files\n");
        return(ERROR_FILE_OPEN);
    }
    /* 2-7 satellite name & band number */
    if(140.6<header[n]->proj->subLon && header[n]->proj->subLon<140.8){
        strcpy(data->satName , "Himawari");
        wgs84 = 1;
    }else if(137.5<header[n]->proj->subLon && header[n]->proj->subLon<142.5){
        strcpy(data->satName , "MTSAT-1R");
        wgs84 = 0;
    }else if(142.5<=header[n]->proj->subLon && header[n]->proj->subLon<147.5){
        strcpy(data->satName , "MTSAT-2");
        wgs84 = 0;
    }
    switch(header[n]->ch){
        case  0: param->band = 3; break; // VIS B03
        case  1: param->band =13; break; // IR1 B13
        case  2: param->band =15; break; // IR2 B15
        case  3: param->band = 8; break; // IR3 B08
        case  4: param->band = 7; break; // IR4 B07
        case  5: param->band = 1; break; //     B01
        case  6: param->band = 2; break; //     B02
        case  7: param->band = 4; break; //     B04
        case  8: param->band = 5; break; //     B05
        case  9: param->band = 6; break; //     B06
        case 10: param->band = 9; break; //     B09
        case 11: param->band =10; break; //     B10
        case 12: param->band =11; break; //     B11
        case 13: param->band =12; break; //     B12
        case 14: param->band =14; break; //     B14
        case 15: param->band =16; break; //     B16
    }
    /* 2-8 ssp */
    data->slon = header[n]->proj->subLon;
    data->slat = 0.0;
    data->sdst = 42164.0e3;
    /* 3 get data */
    for(jj=0;jj<param->height;jj++){
    for(ii=0;ii<param->width;ii++){
        /* 3-1 init */
        count = 65534;
        kk = jj * param->width + ii;
        /* 3-2 convert lon & lat to pix & lin */
        lonlat_to_pixlin(header[n],data->lon[ii],data->lat[jj],&Pix[kk],&Lin[kk],wgs84);
        /* 3-3 min & max line */
        if(Pix[kk] == -9999 || Lin[kk] == -9999){ /* 2021.06 added */
            data->phys[kk] = INVALID;
            continue;
        }
        if(minLine > Lin[kk]) minLine =  Lin[kk];
        if(maxLine < Lin[kk]) maxLine =  Lin[kk];
        /* 3-4 get count value */
        for(ll=0;ll<arg->filenum;ll++){
            if(startLine[ll] -0.5 <=  Lin[kk] && Lin[kk] < endLine[ll] + 0.5){
                hrit_getdata_by_pixlin(header[ll],header[ll]->fp,Pix[kk],Lin[kk],&count);
                break;
            }
        }
        /* 3-5 check count value */
        if(count == 65534){
            data->phys[kk] = INVALID;
        }else{
        /* 3-6 convert count value to physical value */
            data->phys[kk] = header[n]->calib_table[count];
        }
    }
    }
    /* 3-7 pixel and line number before cordinate change */
    data->pix0 = 0;
    for(jj=0;jj<param->height;jj++){
        ii = 0               ; kk = jj * param->width + ii; pix0 = Pix[kk] + 0.5;
        ii = param->width -1 ; kk = jj * param->width + ii; pix1 = Pix[kk] + 0.5;
        if(data->pix0 < (pix1 - pix0 +1) ) data->pix0 = (pix1 - pix0 +1);
    }
    data->lin0 = (int)(maxLine + 0.5) - (int)(minLine + 0.5) + 1;
    /* 3-8 calib table */
    data->nBit = (int)log2((double)header[n]->calib->nLevel);
    data->fVal = (float *)calloc(pow(2,data->nBit),sizeof(float *));
    for(ii=0;ii<pow(2,data->nBit);ii++){
        data->fVal[ii] = header[n]->calib_table[ii];
        // printf("%d %f\n",ii,data->fVal[ii]);
    }
    /* 4 convert maxLine & minLine to scanTime */
    for(ll=0;ll<arg->filenum;ll++){
        /* 4-1 startTime */
        if(startLine[ll] <= minLine && minLine <= endLine[ll]){
            for(ii=1;ii<header[ll]->ot->nLine;ii++){
                if(minLine < header[ll]->ot->otTbl[ii].line ){
                    data->startTime = header[ll]->ot->otTbl[ii-1].mjd;
                    break;
                }
            }
        }
        /* 4-2 endTime */
        if(startLine[ll] <= maxLine && maxLine <= endLine[ll]){
            for(ii=1;ii<header[ll]->ot->nLine;ii++){
                if(maxLine > header[ll]->ot->otTbl[ii].line ){
                    data->endTime = header[ll]->ot->otTbl[ii-1].mjd;
                }
            }
        }
    }
    /* 5 check data */
    printf("Satellite Name : %s\n",data->satName);
    printf("Band Number    : %d\n",param->band);
    printf("physical value :\n        ");
    for(jj=0;jj<param->width ;jj=jj+param->width/10){
        printf("%6.1f  ",data->lon[jj]);
    }
    printf("\n");
    for(ii=0;ii<param->height;ii=ii+param->height/10){
        printf("%6.1f  ",data->lat[ii]);
        for(jj=0;jj<param->width ;jj=jj+param->width/10){
            kk = ii * param->width + jj;
            printf("%6.2f  ",data->phys[kk]);
        }
        printf("\n");
    }
    /* 6 free */
    for(ii=0;ii<arg->filenum;ii++){
        if(header[ii] != NULL){
            hrit_free(header[ii]);
        }
    }
    free(header);
    free(startLine);
    free(endLine);
    free(Pix);
    free(Lin);
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
   convert HRIT file to SATAID file
 -----------------------------------------------------------------------------*/
int main(int argc, char *argv[]){
    parameter   param;
    argument    arg;
    outdata     data;
    long        n_size;
    long        ii;
    FILE        *fp;
    GMSCTL      pctl={0}; /* 2021.06 added */
    CALIB       calb;
    DATA_BLOCK  data_block;

    /* -----------------------------------------------------------------------
       1 get argument
     -----------------------------------------------------------------------*/
    if(NORMAL_END != getArg(argc,argv,&arg,&param)){
	char *cPtr=strrchr(argv[0],'/');
	if(cPtr==NULL)
		{
		cPtr=argv[0];
		}
	else
		{
		cPtr++;
		}
        fprintf(stderr,"Usage : %s [OPTION]\n"
            "  -i <InFile> [-i <InFile2> ...]\n"
            "  -o <OutFile>\n"
            "  -width  <Pixel Number>\n"
            "  -height <Line Number>\n"
            "  -lat    <Left top latitude>\n"
            "  -lon    <Left top longitude>\n"
            "  -dlat   <Spatial resolution (longitude)>\n"
            "  -dlon   <Spatial resolution (latitude)>\n",cPtr);
        return(ERROR_ARG);
    }
    /* -----------------------------------------------------------------------
       2 check parameter
     -----------------------------------------------------------------------*/
    printf("Left top (lat,lon) : (%6.2f,%6.2f)\n",param.ltlat,param.ltlon);
    printf("width,height       : (%6d,%6d)\n",param.width,param.height);
    printf("Spatial resolution : (%6.2f,%6.2f)\n",param.dlat,param.dlon);
    n_size      = param.width * param.height;

    /* -----------------------------------------------------------------------
        3 allocate
     -----------------------------------------------------------------------*/
    /* allocate */
    if( NULL == (data.lat = (float *)calloc(param.height,sizeof(float *))) ||
        NULL == (data.lon = (float *)calloc(param.width, sizeof(float *))) ||
        NULL == (data.phys= (float *)calloc(n_size,      sizeof(float *)))
    ){
        fprintf(stderr,"allocate error\n");
        return(ERROR_CALLOCATE);
    }
    /* init */
    for(ii=0;ii<n_size;ii++){
        data.phys[ii] = INVALID;
    }
    /* -----------------------------------------------------------------------
        4 set longitude and latitude
     -----------------------------------------------------------------------*/
    for(ii=0;ii<param.height;ii++){
        data.lat[ii] = param.ltlat - param.dlat * ii;
    }
    for(ii=0;ii<param.width ;ii++){
        data.lon[ii] = param.ltlon + param.dlon * ii;
    }
    /* -----------------------------------------------------------------------
        5 get data
     -----------------------------------------------------------------------*/
    getData(&arg,&param,&data);
    /* -----------------------------------------------------------------------
        6 make SATAID DATA
     -----------------------------------------------------------------------*/
    // 2 byte data
    if(param.byte == 1){
	    // 1 byte data
    	if( NORMAL_END != makeSataidHeader_1byte(&param,&data,&pctl) ||
        	NORMAL_END != makeSataidCalib_1byte(&data,&pctl,&calb)   ||
	        NORMAL_END != makeSataidData_1byte(&param,&data,&pctl,&calb,&data_block) ){
    	    fprintf(stderr,"make sataid data error\n");
        	return(ERROR_MAKE_DATA);
	    }
	}else if(param.byte == 2){
		// 2 byte data
    	if( NORMAL_END != makeSataidHeader(&param,&data,&pctl) ||
        	NORMAL_END != makeSataidCalib(&data,&pctl,&calb)   ||
	        NORMAL_END != makeSataidData(&param,&data,&pctl,&calb,&data_block) ){
    	    fprintf(stderr,"make sataid data error\n");
        	return(ERROR_MAKE_DATA);
	    }
	}
    /* -----------------------------------------------------------------------
        7 write SATAID DATA
     -----------------------------------------------------------------------*/
    if( NULL == (fp = fopen(arg.OutFile,"wb"))){
        fprintf(stderr,"file open error\n");
        return(ERROR_FILE_OPEN);
    }
    if( NORMAL_END != writeSataidHeader(fp,&pctl) ||
        NORMAL_END != writeSataidCalib(fp,&calb)  ||
        NORMAL_END != writeSataidData(fp,&pctl,&data_block) ){
        fprintf(stderr,"write sataid data error\n");
        return(ERROR_WRITE);
    }
    /* for check */
    printSataidHeader(&pctl);
    printSataidCalib(&calb);
    printSataidData(&pctl,&data_block);
    /* -----------------------------------------------------------------------
        8 end
     -----------------------------------------------------------------------*/
    printf("NORMAL END\n");
    return(NORMAL_END);
}
