/* ----------------------------------------------------------------------------
    Sample source code for Himawari Standard Data or HRIT Data

    Copyright (C) 2014 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of Himawari Standard Format:
        For data structure of Himawari Standard Format, prelese refer to MSC
        Website and Himawari Standard Data User's Guide.

        MSC Website
	https://www.data.jma.go.jp/mscweb/en/index.html

        Himawari Standard Data User's Guide
	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

    Details of HRIT data:
    	Please visit the MSC web site and refer to the document,
    	"JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

    	MSC website:
        https://www.data.jma.go.jp/mscweb/en/index.html
        https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

    	HRIT data:
       	https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

    History
        June,   2015 First release

---------------------------------------------------------------------------- */

typedef struct {
    float   lat, lon;
} GMSPO;

typedef struct {                
    // control block of GMS/MTSAT/Himawari data file
    int     cntl0;              //   1-  4   bytes of block
    char    flid[9];            //   5- 12   kind of image eg:GMS-IR, GMS-VIS
    char    stnm[9];            //  13- 20   sattelite name eg:GMS-4
    int     chno;               //  21- 24   number of channel
    int     sttm[8], entm[8];   //  25- 88   start and end time of picture
    int     coch;               //  89- 92   flag of cordinate change TRUE/FALSE
    int     pix0, lin0;         //  93-100   pixel and line number before cordinate change
    float   pxsz, lnsz;         // 101-108   resolution of pixel and line
    int     pix1, lin1;         // 109-116   pixel and line number after change
    int     recs, btln;         // 117-124   record per line and byte per pixel
    GMSPO   p[4];               // 125-156   lat. and long. of corner of image (deg.)
    int     cals;               // 157-160   calibration number
    int     lvl0, lvl1;         // 161-168   lowest and highest levels of calibration
    int     dumm0[6];           // 169-192   reserved area
    float   roll, pitch, yaw;   // 193-204   attitude of satellite (deg.)
    float   slat, slon, sdst;   // 205-216   position of satellite (deg./R+h:m)
    int     dumm1[8];           // 217-248   reserved area
    char    fver[4];            // 249-252   file version eg:1.1
    int     cntl1;              // 253-256   bytes of block
} GMSCTL;

typedef struct {
    // calibration table
    int     cntl_c0;
    float   *calb_table;
    int     cntl_c1;
} CALIB;

typedef struct {
    // data block
    int        *cntl_d0;
    int        *cntl_d1;
    unsigned short **data_value;  // 2 byte data
    unsigned char  **data_char;   // 1 byte data
} DATA_BLOCK;

typedef struct{
    float   *lon;
    float   *lat;
    float   *phys;
    double  startTime;
    double  endTime;
    char    satName[32];
    int     pix0;
    int     lin0;
    float   slon;   // ssp lon
    float   slat;   // ssp lat
    float   sdst;   // distance
    float   *fVal;  // phy
    unsigned short nBit;
}outdata;

typedef struct{
    short   width;      /* -width    pixel number */
    short   height;     /* -height   line number  */
    double  ltlon;      /* -lon      left top longitude */
    double  ltlat;      /* -lat      left top latitude  */
    double  dlon;       /* -dlon     Spatial resolution (longitude) */
    double  dlat;       /* -dlat     Spatial resolution (latitude) */
    short   band;
    char    byte;
}parameter;

int readSataidHeader(FILE *fp,GMSCTL *pctl);
int readSataidCalib(FILE *fp,GMSCTL *pctl,CALIB *calb);
int readSataidData(FILE *fp,GMSCTL *pctl,CALIB *calb,DATA_BLOCK *data_block);

void printSataidHeader(GMSCTL *pctl);
void printSataidCalib(CALIB *calb);
void printSataidData(GMSCTL *pctl,DATA_BLOCK *data_block);

int writeSataidHeader(FILE *fp,GMSCTL *pctl);
int writeSataidCalib(FILE *fp,CALIB *calb);
int writeSataidData(FILE *fp,GMSCTL *pctl,DATA_BLOCK *data_block);

int makeSataidHeader(parameter *param,outdata *data,GMSCTL *pctl);
int makeSataidCalib(outdata *data,GMSCTL *pctl,CALIB *calb);
int makeSataidData(parameter *param,outdata *data,GMSCTL *pctl,CALIB *calb,
    DATA_BLOCK *data_block);

int makeSataidHeader_1byte(parameter *param,outdata *data,GMSCTL *pctl);
int makeSataidCalib_1byte(outdata *data,GMSCTL *pctl,CALIB *calb);
int makeSataidData_1byte(parameter *param,outdata *data,GMSCTL *pctl,CALIB *calb,
    DATA_BLOCK *data_block);
