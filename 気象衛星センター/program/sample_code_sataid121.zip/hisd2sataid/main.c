/* ----------------------------------------------------------------------------
    Sample source code for Himawari Satandard Data

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of Himawari Standard Format:
        For data structure of Himawari Standard Format, prelese refer to MSC
        Website and Himawari Standard Data User's Guide.

        MSC Website
        https://www.data.jma.go.jp/mscweb/en/index.html

        Himawari Standard Data User's Guide
	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

    History
        June,    2015  First release
	June, 	 2021  Version 2021-06
		       Fixed bug in function  getData() function (main.c)
					      makeSataidHeader() function (sataid_utl.c)
---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hisd.h"
# include "date_utl.h"
# include "sataid_utl.h"
# include "hisd2sataid.h"

# define  MAXFILE   10
# define  INVALID   -1

# define  WIDTH     501    /* default pixel number */
# define  HEIGHT    501    /* default line number */
# define  LTLON   120.0    /* default left top longitude */
# define  LTLAT    50.0    /* default left top latitude */
# define  DLON     0.06    /* default Spatial resolution (longitude) */
# define  DLAT     0.06    /* default Spatial resolution (latitude) */

# define    RECLEN  256
# define    WIDTHLEN(i, j)  ((i+j-1)/j)

typedef struct{
    char    *InFile[MAXFILE+1];
    char    *OutFile;
    char    filenum;
}argument;

/* ------------------------------------------------------------------------- */
int getArg(int argc, char **argv, argument *arg,parameter *param);
int getData(argument *arg,parameter *param,outdata *data);
/* ---------------------------------------------------------------------------
  getArg()
 -----------------------------------------------------------------------------*/
int getArg(int argc, char **argv, argument *arg,parameter *param){
    char    *ptr;
    int     ii,nn=0;
    /* 1 init */
    arg->OutFile = NULL;
    for(ii=0;ii<MAXFILE;ii++){
        arg->InFile[ii] = NULL;
    }
    param->ltlat = LTLAT;   /* left top longitude */
    param->ltlon = LTLON;   /* left top longitude */
    param->width = WIDTH;   /* pixel number  */
    param->height= HEIGHT;  /* line number  */
    param->dlon  = DLON;    /* Spatial resolution (longitude) */
    param->dlat  = DLAT;    /* Spatial resolution (latitude) */
    param->byte  = 1;       /* byte per pixel */
    /* 2 get arguments */
    for(ii=1;ii<argc-1;ii++){
        ptr=argv[ii];
        if(*ptr=='-'){
            ptr++;
            switch (*ptr){
                case 'o':   /* output file */
                    arg->OutFile = argv[ii+1];
                    ii++;
                    break;
                case 'i':   /* input file */
                    if(nn<MAXFILE){
                        arg->InFile[nn] = argv[ii+1];
                        nn++;
                    }else{
                        fprintf(stderr,"InFile : %s [%d/%d]\n",
                            argv[ii+1],nn,MAXFILE);
                    }
                    ii++;
                    break;
                case 'd':
                case 'l':
                case 'w':
                case 'h':
                case 'b':
                    if(!strcmp(ptr,"lon")){
                        param->ltlon = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"lat")){
                        param->ltlat = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"width")){
                        param->width = atoi(argv[ii+1]);
                    }else if(!strcmp(ptr,"height")){
                        param->height = atoi(argv[ii+1]);
                    }else if(!strcmp(ptr,"dlon")){
                        param->dlon = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"dlat")){
                        param->dlat = atof(argv[ii+1]);
                    }else if(!strcmp(ptr,"byte")){
                        param->byte = atoi(argv[ii+1]);
                    }
                    ii++;
                    break;
            }
        }
    }
    arg->filenum = nn;
    /* 4 check parameter */
    if(param->width < 10){param->width =10;}
    if(param->height< 10){param->height=10;}
    if(param->ltlat < -90.  || 90.< param->ltlat){ param->ltlat = LTLAT;}
    if(param->ltlon <-180.  ||180.< param->ltlon){ param->ltlon = LTLON;}
    if(param->dlat  < 0. || 10. < param->dlat ){param->dlat = DLAT;}
    if(param->dlon  < 0. || 10. < param->dlon ){param->dlon = DLON;}
    /* 4 check error */
    if(arg->InFile[0]==NULL || arg->OutFile==NULL){
        return(ERROR_ARG);
    }
    /* 5 return */
    return(NORMAL_END);
}


/* ---------------------------------------------------------------------------
  getData()
 -----------------------------------------------------------------------------*/
int getData(argument *arg,parameter *param,outdata *data){

    HisdHeader      **header;
    FILE            **fp;
    float           *Pix,*Lin;
    unsigned short  *startLine;
    unsigned short  *endLine;
    unsigned int    ii,jj,kk,ll;
    int             n;
    unsigned short  count;
    float           radiance;
    unsigned long   n_size = param->height * param->width;
    double          phys;
    float           minLine = 99999.0;
    float           maxLine =-99999.0;
    int                pix0,pix1;

    /* 1 allocate */
    if( NULL == ( header = (HisdHeader **)calloc(arg->filenum,sizeof(HisdHeader *))) ||
        NULL == ( fp = (FILE **)calloc(arg->filenum,sizeof(FILE *))) ||
        NULL == ( startLine = (unsigned short *)calloc(arg->filenum,sizeof(unsigned short *))) ||
        NULL == ( endLine   = (unsigned short *)calloc(arg->filenum,sizeof(unsigned short *))) ||
        NULL == ( Pix = (float *)calloc(n_size,sizeof(float *))) ||
        NULL == ( Lin = (float *)calloc(n_size,sizeof(float *)))
    ){
        fprintf(stderr,"callocate error\n");
        return(ERROR_CALLOCATE);
    }
    n = -1;
    for(ii=0;ii<arg->filenum;ii++){
        /* 2-1 open file */
        if(NULL == ( fp[ii] = fopen(arg->InFile[ii],"rb"))){
            fprintf(stderr,"error : can not open [%s]\n",arg->InFile[ii]);
            continue;
        }
        /* 2-2 callocate */
        if(NULL == (header[ii] = (HisdHeader *)calloc(1,sizeof(HisdHeader)))){
            fprintf(stderr,"callocate error\n");
            return(ERROR_CALLOCATE);
        }
        /* 2-3 read hisd header */
        if(NORMAL_END != hisd_read_header(header[ii],fp[ii])){
            fprintf(stderr,"error : read header [%s]\n",arg->InFile[ii]);
            continue;
        }
        /* 2-4 starLine and endLine */
        startLine[ii] = header[ii]->seg->strLineNo;
        endLine[ii]   = startLine[ii] + header[ii]->data->nLin -1;
        /* 2-5 check header consistency */
        if(n==-1)n=ii;
        if( header[n]->calib->bandNo       != header[ii]->calib->bandNo ||
            header[n]->calib->gain_cnt2rad != header[ii]->calib->gain_cnt2rad ||
            header[n]->proj->loff          != header[ii]->proj->loff    ||
            header[n]->proj->coff          != header[ii]->proj->coff    ){
            fprintf(stderr,"header consistency error\n");
            fprintf(stderr,"%s : %s\n",arg->InFile[n],arg->InFile[ii]);
            return(ERROR_INFO);
        }
        n=ii;
    }
    /* 2-6 check file open */
    if(n==-1){
        fprintf(stderr,"error : can not open all files\n");
        return(ERROR_FILE_OPEN);
    }
    /* 2-6 satellite name & band number */
    param->band = header[n]->calib->bandNo;
    strcpy(data->satName , header[n]->basic->satName);

    /* 2-8 ssp */
    data->slon = header[n]->nav->sspLon;
    data->slat = header[n]->nav->sspLat;
    data->sdst = header[n]->nav->satDis;

    /* 3 get data */
    for(jj=0;jj<param->height;jj++){
    for(ii=0;ii<param->width;ii++){
        /* 3-1 init */
        count = header[n]->calib->outCount;
        kk = jj * param->width + ii;
        /* 3-2 convert lon & lat to pix & lin */
        lonlat_to_pixlin(header[n],data->lon[ii],data->lat[jj],&Pix[kk],&Lin[kk]);

        /* 3-3 min & max line */
        if(Pix[kk] == -9999 || Lin[kk] == -9999){ /* 2021.06 added */
            data->phys[kk] = INVALID;
            continue;
        }
        if(minLine > Lin[kk]) minLine =  Lin[kk];
        if(maxLine < Lin[kk]) maxLine =  Lin[kk];
        /* 3-4 get count value */
        for(ll=0;ll<arg->filenum;ll++){
        //  if(startLine[ll] <=  Lin[kk]+0.5 && Lin[kk]+0.5 <= endLine[ll]){
            if(startLine[ll] -0.5 <=  Lin[kk] && Lin[kk] < endLine[ll] + 0.5){
                hisd_getdata_by_pixlin(header[ll],fp[ll],Pix[kk],Lin[kk],&count);
                break;
            }
        }
        /* 3-5 check count value */
        if( count == header[n]->calib->outCount ||
            count == header[n]->calib->errorCount){
            data->phys[kk] = INVALID;
        }else{
        /* 3-6 convert count value to radiance */
            radiance = (float)count * header[n]->calib->gain_cnt2rad +
                        header[n]->calib->cnst_cnt2rad;
        /* 3-6 convert radiance to physical value */
            if( (header[n]->calib->bandNo>=7 &&
                 strstr(header[n]->basic->satName,"Himawari")!=NULL ) ||
                (header[n]->calib->bandNo>=2 &&
                 strstr(header[n]->basic->satName,"MTSAT-2") !=NULL )){
                /* infrared band */
                hisd_radiance_to_tbb(header[n],radiance,&phys);
                data->phys[kk] = (float)phys ;
            }else{
                /* visible or near infrared band */
                data->phys[kk] = header[n]->calib->rad2albedo * radiance;
            }
        }
    }
    }
    /* 3-7 pixel and line number before cordinate change */
    data->pix0 = 0;
    for(jj=0;jj<param->height;jj++){
        ii = 0               ; kk = jj * param->width + ii; pix0 = Pix[kk] + 0.5;
        ii = param->width -1 ; kk = jj * param->width + ii; pix1 = Pix[kk] + 0.5;
        if(data->pix0 < (pix1 - pix0 +1) ) data->pix0 = (pix1 - pix0 +1);
    }
    data->lin0 = (int)(maxLine + 0.5) - (int)(minLine + 0.5) + 1;

    /* 3-8 calib table */
    data->nBit = header[n]->calib->bitPix;
    data->fVal = (float *)calloc(pow(2,data->nBit),sizeof(float *));
    for(ii=0;ii<pow(2,data->nBit);ii++){
        radiance = (float)ii * header[n]->calib->gain_cnt2rad +
                    header[n]->calib->cnst_cnt2rad;
        if( (header[n]->calib->bandNo>=7 &&
             strstr(header[n]->basic->satName,"Himawari")!=NULL ) ||
            (header[n]->calib->bandNo>=2 &&
             strstr(header[n]->basic->satName,"MTSAT-2") !=NULL )){
            /* infrared band */
            hisd_radiance_to_tbb(header[n],radiance,&phys);
            data->fVal[ii] = phys;
        }else{
            /* visible or near infrared band */
            data->fVal[ii] = header[n]->calib->rad2albedo * radiance;
        }
        if(data->fVal[ii] == -10000000000.000000 && ii >1){
            data->fVal[ii] = data->fVal[ii-1];
        }
    //    printf("%d %f\n",ii,data->fVal[ii]);
    }

    /* 4 convert maxLine & minLine to scanTime */
    for(ll=0;ll<arg->filenum;ll++){
        /* 4-1 startTime */
        if(startLine[ll] <= minLine && minLine <= endLine[ll]){
            for(ii=1;ii<header[ll]->obstime->obsNum;ii++){
                if(minLine < header[ll]->obstime->lineNo[ii]){
                    data->startTime = header[ll]->obstime->obsMJD[ii-1];
                    break;
                }else if(minLine == header[ll]->obstime->lineNo[ii]){
                    data->startTime = header[ll]->obstime->obsMJD[ii];
                    break;
                }
            }
        }
        /* 4-2 endTime */
        if(startLine[ll] <= maxLine && maxLine <= endLine[ll]){
            for(ii=1;ii<header[ll]->obstime->obsNum;ii++){
                if(maxLine < header[ll]->obstime->lineNo[ii]){
                    data->endTime = header[ll]->obstime->obsMJD[ii-1];
                    break;
                }else if(maxLine == header[ll]->obstime->lineNo[ii]){
                    data->endTime = header[ll]->obstime->obsMJD[ii];
                    break;
                }
            }
        }
    }

    /* 5 check data */
    printf("Satellite Name : %s\n",data->satName);
    printf("Band Number    : %d\n",param->band);
    printf("physical value :\n        ");
    for(jj=0;jj<param->width ;jj=jj+param->width/10){
        printf("%6.1f  ",data->lon[jj]);
    }
    printf("\n");
    for(ii=0;ii<param->height;ii=ii+param->height/10){
        printf("%6.1f  ",data->lat[ii]);
        for(jj=0;jj<param->width ;jj=jj+param->width/10){
            kk = ii * param->width + jj;
            printf("%6.2f  ",data->phys[kk]);
        }
        printf("\n");
    }

    /* 6 free */
    for(ii=0;ii<arg->filenum;ii++){
        if(header[ii] != NULL){
            hisd_free(header[ii]);
        }
        if(fp[ii]     != NULL){
             fclose(fp[ii]);
        }
    }
    free(header);
    free(fp);
    free(startLine);
    free(endLine);
    free(Pix);
    free(Lin);
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  convert HISD file to SATAID file
 -----------------------------------------------------------------------------*/
int main(int argc, char *argv[]){
    parameter   param;
    argument    arg;
    outdata     data;
    long        n_size;
    long        ii;
    FILE         *fp;
    GMSCTL         pctl={0};
    CALIB          calb;
    DATA_BLOCK     data_block;
    

    /* -----------------------------------------------------------------------
        1 get argument
     -----------------------------------------------------------------------*/
    if(NORMAL_END != getArg(argc,argv,&arg,&param)){
	char *cPtr=strrchr(argv[0],'/');
	if(cPtr==NULL)
		{
		cPtr=argv[0];
		}
	else
		{
		cPtr++;
		}
        fprintf(stderr,"Usage : %s [OPTION]\n"
            "  -i <InFile> [-i <InFile2> ...]\n"
            "  -o <OutFile>\n"
            "  -width  <Pixel Number>\n"
            "  -height <Line Number>\n"
            "  -lat    <Left top latitude>\n"
            "  -lon    <Left top longitude>\n"
            "  -dlat   <Spatial resolution (longitude)>\n"
            "  -dlon   <Spatial resolution (latitude)>\n"
            "  -byte   <byte number of data block [1|2]>\n",cPtr);

        return(ERROR_ARG);
    }
    /* -----------------------------------------------------------------------
        2 check parameter
     -----------------------------------------------------------------------*/
    printf("Left top (lat,lon) : (%6.2f,%6.2f)\n",param.ltlat,param.ltlon);
    printf("width,height       : (%6d,%6d)\n",param.width,param.height);
    printf("Spatial resolution : (%6.2f,%6.2f)\n",param.dlat,param.dlon);
    n_size      = param.width * param.height;
    /* -----------------------------------------------------------------------
        3 allocate
     -----------------------------------------------------------------------*/
    /* allocate */
    if( NULL == (data.lat = (float *)calloc(param.height,sizeof(float *))) ||
        NULL == (data.lon = (float *)calloc(param.width, sizeof(float *))) ||
        NULL == (data.phys= (float *)calloc(n_size,      sizeof(float *)))
    ){
        fprintf(stderr,"allocate error\n");
        return(ERROR_CALLOCATE);
    }
    /* init */
    for(ii=0;ii<n_size;ii++){
        data.phys[ii] = INVALID;
    }
    /* -----------------------------------------------------------------------
        4 set longitude and latitude
     -----------------------------------------------------------------------*/
    for(ii=0;ii<param.height;ii++){
        data.lat[ii] = param.ltlat - param.dlat * ii;
    }
    for(ii=0;ii<param.width ;ii++){
        data.lon[ii] = param.ltlon + param.dlon * ii;
    }
    /* -----------------------------------------------------------------------
        5 get data
     -----------------------------------------------------------------------*/
    if(NORMAL_END != getData(&arg,&param,&data)){
      fprintf(stderr,"get data error\n");
        free(data.lon);
        free(data.lat);
        free(data.phys);
        return(ERROR_READ_DATA);
    }
    /* -----------------------------------------------------------------------
        6 make SATAID DATA
     -----------------------------------------------------------------------*/
    // 2 byte data
    if(param.byte == 2){
        if( NORMAL_END != makeSataidHeader(&param,&data,&pctl) ||
            NORMAL_END != makeSataidCalib(&data,&pctl,&calb)   ||
            NORMAL_END != makeSataidData(&param,&data,&pctl,&calb,&data_block) ){
            fprintf(stderr,"make sataid data error\n");
            return(ERROR_MAKE_DATA);
        }
    }else{
        // 1 byte data
        if( NORMAL_END != makeSataidHeader_1byte(&param,&data,&pctl) ||
            NORMAL_END != makeSataidCalib_1byte(&data,&pctl,&calb)   ||
            NORMAL_END != makeSataidData_1byte(&param,&data,&pctl,&calb,&data_block) ){
            fprintf(stderr,"make sataid data error\n");
            return(ERROR_MAKE_DATA);
        }
    }
    /* -----------------------------------------------------------------------
        7 write SATAID DATA
     -----------------------------------------------------------------------*/
    if( NULL == (fp = fopen(arg.OutFile,"wb"))){
        fprintf(stderr,"file open error\n");
        return(ERROR_FILE_OPEN);
    }
    if( NORMAL_END != writeSataidHeader(fp,&pctl) ||
        NORMAL_END != writeSataidCalib(fp,&calb)  ||
        NORMAL_END != writeSataidData(fp,&pctl,&data_block) ){
        fprintf(stderr,"write sataid data error\n");
        return(ERROR_WRITE);
    }
    /* for check */
    printSataidHeader(&pctl);
    printSataidCalib(&calb);
    printSataidData(&pctl,&data_block);
    /* -----------------------------------------------------------------------
        6 end
     -----------------------------------------------------------------------*/
    printf("NORMAL END\n");
    return(NORMAL_END);
}

