MSC has developed a C sample program for converting the Himawari Standard Data to SATAID Data.
This sample converts Himawari Standard Data to SATAID Data.
It has been compiled and checked on Linux (RedHat, 64bit).
We would appreciate it if you could give us some comments or/and bug reports (E-mail: jma-msc-contact@ml.kishou.go.jp).

Files:
	hisd.h 			- define the structure of the header of the Himawari Standard Data
	hisd2sataid.h 		- header file for main function
	date_utl.h 		- header file for MJD function
	sataid_utl.h 		- header file for SATAID data function
	main.c 			- main function
	hisd_pixlin2lonlat.c 	- function for projection transformation
	hisd_read.c 		- function for reading the Himawari Standard Data
	date_utl.c 		- function for Modified Julian Day
	sataid_utl.c 		- function for SATAID Data

Make/Run
	(1) extract zip file (>unzip sample_code_sataid121.zip )
	(2) make executable file (>make )
	(3) run the file (>hisd2sataid -i InFile1 [-i InFile2 ...] -o OutFile )

Note:
	There are 6 parameters to define the area scope of SATAID Data.
	These parameters are defined in main function.
		WIDTH : pixel number
		HEIGHT : line number
		LTLON : left top longitude
		LTLAT : left top latitude
		DLON : spatial resolution (longitude)
		DLAT : spatial resolution (latitude)

	Run the executable file without arguments. Usage is outlined below.

	Usage : hisd2sataid [OPTION]
		-i <InFile> [-i <InFile2> ...]
		-o <OutFile>
		-width <Pixel Number>
		-height <Line Number>
		-lat <Left top latitude>
		-lon <Left top longitude>
		-dlat <Spatial resolution (longitude)>
		-dlon <Spatial resolution (latitude)>
		-byte <byte number of data block [1|2]>

	The output data area can also be specified using these options.
	E.g. To output an area of (40°N, 130°E) – (30°N, 140°E) with a 0.02-degree grid scale, use:
	hisd2sataid -width 501 -height 501 -lat 40 -lon 130 -dlat 0.02 -dlon 0.02 -i InFile1 -i InFile2 -i InFile3 … -o OutFile

	Missing grid points for any part of the area (40°N, 130°E) - (30°N, 140°E) in input file content will have invalid values in output file content.

Disclaimer:
	MSC does not guarantee regarding the correctness, accuracy, reliability, or any other aspect regarding use of these sample codes.

Detail of Himawari Standard Format:
	For data structure of Himawari Standard Format, please refer to MSC Website and Himawari Standard Data User's Guide.

	MSC Website
	https://www.data.jma.go.jp/mscweb/en/index.html

	Himawari Standard Data User's Guide
	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

History
	June, 2015 First release
	June, 2021 Version 2021-06
		   Fixed bug in function getData() function (main.c)
				         makeSataidHeader() function (sataid_utl.c)

