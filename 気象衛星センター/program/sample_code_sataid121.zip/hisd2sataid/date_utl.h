/* ----------------------------------------------------------------------------
	Sample source code for Himawari Satandard Data or HRIT Data

	Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

	Disclaimer:
		MSC does not guarantee regarding the correctness, accuracy, reliability,
		or any other aspect regarding use of these sample codes.

	Detail of Himawari Standard Format:
		For data structure of Himawari Standard Format, prelese refer to MSC
		Website and Himawari Standard Data User's Guide.

		MSC Website
		https://www.data.jma.go.jp/mscweb/en/index.html	

		Himawari Standard Data User's Guide
		https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

	Details of HRIT data:
    		Please visit the MSC web site and refer to the document,
    		"JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

    		MSC website:
        	https://www.data.jma.go.jp/mscweb/en/index.html
        	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

    		HRIT data:
       		https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

	History
		March,   2015  First release

---------------------------------------------------------------------------- */

void mjd_to_date(double mjd, int date[7]);
void DateGetNowInts(int  date[7] );
double DateIntsToMjd(const int date[7] );
