MSC has developed a C sample program for converting the Himawari Standard Data to HRIT Data.
This sample converts Himawari Standard Data to HRIT Data.
It has been compiled and checked on LINUX (RedHat, 64bit)
We would appreciate it if you could give us some comments or/and bug reports (E-mail: jma-msc-contact@ml.kishou.go.jp).

Files:
	main.c         - main function
	hisd2hrit.h    - header file for main function
	hisd.h         - define the structure of the header of the Himawari Standard Data
	date_utl.h     - header file for MJD function
	hisd_read.c    - function for reading the Himawari Standard Data
	hrit.h         - define the structure of the header of the HRIT Data
	hrit_utl.c     - function for making HRIT Data
	date_utl.c     - function for Modified Julian Day

Make/Run
	(1) extract zip file        (>unzip sample_code_hrit122.zip      )
	(2) make executable file    (>make                     )
	(3) run the file            (>hisd2hrit SampleFileName )

Note:
	Output filename convention
		IMG_DK01ccc_yyyymmddhhmi_qqq
	
		ccc	 : channel name 
				IR1 : band 13
				IR2 : band 15
				IR3 : band 08
				IR4 : band 07
				VIS : band 03
				Bnn : other band
		yyyy : Observation start time (timeline) [year] (4 digits)
		mm   : Observation start time (timeline) [month] (01-12)
		dd   : Observation start time (timeline) [day]   (01-31)
		hh   : Observation start time (timeline) [hour]  (00-23)
		nn   : Observation start time (timeline) [min.] 
		qqq  : segment number

Disclaimer:
	MSC does not guarantee regarding the correctness, accuracy, reliability, or any other aspect regarding use of these sample codes.

Detail of Himawari Standard Format:
	For data structure of Himawari Standard Format, please refer to MSC Website and Himawari Standard Data User's Guid.

	MSC Website
	https://www.data.jma.go.jp/mscweb/en/index.html

	Himawari Standard Data User's Guid
	https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

History
	March,   2015  First release
    	May,     2015  Fixed bug in function copy_str() 
                       Changed the default "byte order"
	June,    2015  Verision 2015-06
                       Fixed bug in function hisd_read_header() (hisd_read.c)
	September, 2015 Version 2015-09
                        Fixed bug in function make_calib_table() (hrit_utl.c)
	October, 2015  Version 2015-10
                       Fixed bug in function make_compesation_table() (hrit_utl.c)
