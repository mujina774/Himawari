/* ----------------------------------------------------------------------------
	Sample source code for Himawari Satandard Data

	Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

	Disclaimer  :
		MSC does not guarantee regarding the correctness, accuracy, reliability,
		or any other aspect regarding use of these sample codes.

	Detail of Himawari Standard Format :
		For data structure of Himawari Standard Format, prelese refer to MSC
		Website and Himawari Standard Data User's Guid.

		MSC Website
		https://www.data.jma.go.jp/mscweb/en/index.html

		Himawari Standard Data User's Guid
		https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

	History
		March,   2015  First release
		May,     2015  Change for version 1.2
        	June,    2015  Verision 2015-06
                               Fixed bug in function hisd_read_header() (hisd_read.c)
		September,2015 Fixed bug in function make_calib_table() (hrit_utl.c)
		October, 2015  Fixed bug in function make_compesation_table() (hrit_utl.c)
---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hisd.h"
# include "hrit.h"
# include "hisd2hrit.h"

/* ---------------------------------------------------------------------------
  convert HISD file to HRIT file
 -----------------------------------------------------------------------------*/
int main(int argc, char *argv[]){

	HisdHeader	*hisd;			// HISD header infomation
	HritHeader	*hrit;			// HRIT header infomation
	unsigned short	*hisd_data;	// HISD data block
	unsigned short	*hrit_data;	// HRIT data block
	FILE		*fp;			// input  [HISD]
	FILE		*fo;			// output [HRIT]
	char		*InFile;		// input file name
	double 		*radiance_table;
	unsigned long n_size;		// number of pixels

	// -----------------------------------------------------------------------
	// 1 prepare
	// -----------------------------------------------------------------------
	if(argc != 2){
		char *cPtr=strrchr(argv[0],'/');
		if(cPtr==NULL)
                {
                cPtr=argv[0];
                }
        else
                {
                cPtr++;
                }
		fprintf(stderr,"usage : %s HISD_FILE\n",cPtr);
		return(ERROR_ARG);
	}
	InFile = argv[1];
	if(NULL==(fp=fopen(InFile,"rb"))){
		fprintf(stderr,"file open error\n");
		return(ERROR_FILE_OPEN);
	}
	// -----------------------------------------------------------------------
	// 2 read hisd haeader
	// -----------------------------------------------------------------------
	hisd = (HisdHeader *)calloc(1,sizeof(HisdHeader));
	if(hisd == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if(NORMAL_END != hisd_read_header(hisd,fp)){
		fprintf(stderr,"hisd_read_header() : errorr\n");
		return(ERROR_READ_HEADER);
	}
	// -----------------------------------------------------------------------
	// 3 read hisd daba block
	// -----------------------------------------------------------------------
	n_size = hisd->data->nPix * hisd->data->nLin;
	hisd_data = (unsigned short *)calloc(n_size,sizeof(unsigned short));
	if(hisd_data == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if( n_size > fread(hisd_data,sizeof(unsigned short),n_size,fp)){
		fprintf(stderr,"data read error\n");
		return(ERROR_READ_DATA);
	}
	// -----------------------------------------------------------------------
	// 4 byte swap
	// -----------------------------------------------------------------------
	if(byteOrder() != hisd->basic->byteOrder ){
		swapBytes(&hisd_data[0],sizeof(unsigned short),n_size);
	}
	// -----------------------------------------------------------------------
	// 5 make hrit header
	// -----------------------------------------------------------------------
	hrit = (HritHeader *)calloc(1,sizeof(HritHeader));
	radiance_table = (double *)calloc(pow(2,BITNUM),sizeof(double));
	if(hisd == NULL || radiance_table == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if(0 != make_hrit_header(hisd,hrit,radiance_table)){
		fprintf(stderr,"error : make_hrit_header()\n");
		return(ERROR_MAKE_HEADER);
	}
	// -----------------------------------------------------------------------
	// 6 make hrit data block
	// -----------------------------------------------------------------------
	hrit_data = (unsigned short *)calloc(n_size,sizeof(unsigned short));
	if(hrit_data == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if(0 != make_hrit_data(hisd,hrit,hisd_data,hrit_data,radiance_table)){
		fprintf(stderr,"error : make_hrit_data()\n");
		return(ERROR_MAKE_DATA);
	}
	// -----------------------------------------------------------------------
	// 7 write hrit header
	// -----------------------------------------------------------------------
	fo=fopen(hrit->annt->annt,"wb");
	if(fo == NULL){
		fprintf(stderr,"output file [%s] : open error\n",hrit->annt->annt);
		return(ERROR_FILE_OPEN);
	}
	if(0 != write_hrit_header(hrit,fo,ENDIAN)){
		fprintf(stderr,"error : write_hrit_header()\n");
		return(ERROR_WRITE);
	}
	// -----------------------------------------------------------------------
	// 8 write hrit data block
	// -----------------------------------------------------------------------
	if(0 != write_data(hrit_data,n_size,fo,ENDIAN)){
		fprintf(stderr,"error : write_hrit_dat\n");
		return(ERROR_WRITE);
	}
	printf("Input  File Name : %s\n",InFile);
	printf("Output File Name : %s\n",hrit->annt->annt);
	printf("HRIT Header Total Length : %ld\n",hrit->prim->hdrLen);
	printf("HRIT Data Length : %ld\n",(long)(hrit->prim->fDatLen/8));
	// -----------------------------------------------------------------------
	// 8 end
	// -----------------------------------------------------------------------
	fclose(fp); 			fclose(fo);
	free(hisd_data); 		free(hrit_data);
	free(hrit->prim); 		free(hrit->str);
	free(hrit->nav); 		free(hrit->datfunc);
	free(hrit->annt); 		free(hrit->stamp);
	free(hrit->seg); 		free(hrit->compinfo);
	free(hrit->obstime); 	free(hrit->qual);
	free(hrit);
	free(radiance_table);
	hisd_free(hisd);
	return(NORMAL_END);
}

