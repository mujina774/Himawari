/* ----------------------------------------------------------------------------

    Sample source code for HRIT Data

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer:
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of HRIT data:
        Please visit the MSC web site and refer to the document,
        "JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

        MSC website:
        https://www.data.jma.go.jp/mscweb/en/index.html
        https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

        HRIT data:
        https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

    History
        June,    2015  First release

  ---------------------------------------------------------------------------- */

#ifndef _SP_HRIT_INCLUDE
#define _SP_HRIT_INCLUDE

#define SP_HRIT_SMALL_MEM 	0
#define SP_HRIT_LITTLE 		0  /* CPU ENDIAN */

#define SP_HRIT_HEADER_TYPE_IMG 0
#define SP_HRIT_HEADER_TYPE_GTS 1
#define SP_HRIT_HEADER_TYPE_TXT 2
#define SP_HRIT_HEADER_TYPE_ENC 3

#define SP_HRIT_COMP_NONE 0
#define SP_HRIT_COMP_LSLS 1
#define SP_HRIT_COMP_LOSS 2

#define SP_HRIT_DISK 	1
#define SP_HRIT_PS 		2
#define SP_HRIT_MERC 	3

#define SP_HRIT_ALBEDO 	1
#define SP_HRIT_RAD 	2
#define SP_HRIT_TEMP 	3
#define SP_HRIT_LEVEL 	4
#define SP_HRIT_NOELEM -9999

/* ERROR CODE */
#define SP_HRIT_NORMAL 	0
#define SP_HRIT_MEM 	1
#define SP_HRIT_FOPEN 	2
#define SP_HRIT_FREAD 	3
#define SP_HRIT_FORM 	4

/* Constants */
#define SP_HRIT_INVALID -1


/**
	#0 Primary Header
************************/
typedef struct primaryHeader
	{
	unsigned char hdrType;		/**< Header Type */
	unsigned short recLen;		/**< Header Record Lengh */
	unsigned char typeCode;		/**< File Type Code */
	unsigned long hdrLen;		/**< Total Header Length */
	unsigned long datLen[2];	/**< Data Field Length */
	float fDatLen;				/**< Data Field Length (float) */
	}SpHritPrimary;

/**
	#1 Image Structure	
************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Lengh */
	unsigned char bitPix;	/**< Number of Bits Per Pixel */
	unsigned short nPix;	/**< Number of Columns */
	unsigned short nLin;	/**< Number of Lines */
	unsigned char comp;		/**< Compression Method */
	}SpHritImgStruct;

/**
	#2 Image Navigation 
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char projName[33];		/**< Projection Name */
	long cfac;				/**< Column Scaling Factor */
	long lfac;				/**< Line Scaling Factor */
	long coff;				/**< Column Offfset */
	long loff;				/**< Line Offset */
	}SpHritNav;

/**
	#3 Image Data Function
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *datDef;			/**< Data Definition Block */
	}SpHritDataFunc;

/**
	#4 Annotation 
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *annt;				/**< Annotation Text */
	}SpHritAnnt;

/**
	#5 Time Stamp
*******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	unsigned char cdsP;		/**< CDS P Field */
	unsigned short cdsTD;	/**< CDS T Field (Counter of Days Starting from Jan 1, 1958) */
	unsigned long cdsTS;	/**< CDS T Field (Milliseconds of Day) */
	}SpHritTimeStamp;
	
/** not use
	#6 Ancillary Text
****************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	char *ancText;			**< Ancillary Text *
	}SpHritAncillary;
*/

/* not use
	#7 Key Header
****************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	unsigned long keyNo;
	}SpHritKey;
*/

/**
	#128 Image Segment Identification
****************************************/
typedef struct
	{
	unsigned char hdrType;		/**< Header Type */
	unsigned short recLen;		/**< Header Record Length */
	unsigned char segSeqNo;		/**< Image Segment Sequentional Number */
	unsigned char totalSegNo;	/**< Total Number of Image Segments */
	unsigned short segLineNo;	/**< Total Number of Line Image Segments */
	}SpHritImgSegmentId;
	
/** not use
	#129 Encryption Key Message Header
****************************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	unsigned short stnNo;	**< Index of the User Station *
	}SpHritEncKeyMsg;
*/

/**
	# 130 Image Compensation Information Header
*********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *compInfo;			/**< Image Compensation Information */
	}SpHritImgCompInfo;

/**
	# 131 Image Observation Time Header
********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *obsTime;			/**< Image Observation Time */
	}SpHritImgObsTime;

/**
	# 132 Image Quality Information Header
********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *qInfo;			/**< Image Quality Information */
	}SpHritQualityInfo;

/**
	Calibration Table
********************************************/
typedef struct
	{
	int level;
	float phys;
	}SpHritCalTable;

/**
	Calibration Parameters
********************************************/
typedef struct
	{
	SpHritCalTable *calTbl;
	int nTbl;
	int nLevel;
	}SpHritCalib;

/**
	Compensation Table
*****************************************/
typedef struct
	{
	int line;
	float coff;
	float loff;
	}SpHritCompTable;

/**
	Compensation Parameters
*******************************************/
typedef struct
	{
	SpHritCompTable *compTbl;
	int nLine;
	}SpHritComp;

/*
	ScanTime
******************************************/
typedef struct
	{
	int line;
	double mjd;
	}SpHritObsTimeTable;

/**
	ScanTime
******************************************/
typedef struct
	{
	SpHritObsTimeTable *otTbl;
	int nLine;
	}SpHritObsTime;

/**
	Projection
******************************************/
typedef struct
	{
	double subLon;
	double prjDir;
	double prjLon;
	}SpHritProj;


/**
	HRIT Definition
*******************************************/
typedef struct
	{
	char *fileName;			/**< File Name */
	char satName[12];		/**< Satellite Name */
	int ch;					/**< Channel 0:VIS 1:IR1 2:IR2 3:IR3 4:IR4 */ 
                            /**< Himawari-8,9
                                 5 :B01 6 :B02 7 :B04 8 :B05 9 :B06 10:B09
                                 11:B10 12:B11 13:B12 14:B14 15:B16 */
	int elem;				/**< Element 1:Albedo 2:Radiation 3:Temperature 4:Level */

	/* HRIT Header */
	SpHritPrimary *prim;
	SpHritImgStruct *str;
	SpHritNav *nav;
	SpHritDataFunc *datfunc;
	SpHritAnnt *annt;
	SpHritTimeStamp *stamp;
	SpHritImgSegmentId *seg;
	SpHritImgCompInfo *compinfo;
	SpHritImgObsTime *obstime;
	SpHritQualityInfo *qual;

	/* Calibration */
	SpHritCalib *calib;
	float       *calib_table;

	/* Compensation */
	SpHritComp *comp;

	/* ScanTime */
	SpHritObsTime *ot;

	/*  Navigation */
	SpHritProj *proj;

	/* Internal */
	short startLineNo;			/**< First Column No (c,l) 1,2, .... */
	short endLineNo;			/**< First Line No (c,l) 1,2, .... */
	short nLine;				/**< Number of Lines  */
	short nFrameLine;			/**< Number of Lines in HRIT Frame */
	short nPixel;				/**< Number of Pixels */
	float diffPix;				/**< Shift (Pixel) */
	float diffLin;				/**< Shift (Line)  */
	unsigned short **lineData;	/**< lineData[0 .. nLine-1] */
	FILE *fp;					/**< File Pointer */
	float fCalTbl[1024];		/**< Calibration Table */
	float *cmpCoff,*cmpLoff;	/**< Compensation */
	double *imgQual;			/**< Error Pixel Rate */
	short cpuEndian;			/**< Endian (0:Little 1:Big) */
	}SpHritFile;

/**
	HRIT Navigation Information
*******************************************/
typedef struct
	{
	double scanTime;
	}SpNavPointInfo;
/*
	Function
****************************************************************/

int lonlat_to_pixlin(SpHritFile *info,double lon,double lat,
    float *pix,float *lin,int flag);
int hrit_getdata_by_pixlin(SpHritFile *header,FILE *fp, float hPix,float hLin,
    unsigned short *sout);

int hrit_read_header(SpHritFile *info,const char *fileName);
int hrit_free(SpHritFile *info);
void spHritSwapBytes(void *buf,int size,int nData);

#endif
