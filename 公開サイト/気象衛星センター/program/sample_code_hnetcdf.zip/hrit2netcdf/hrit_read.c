/* ----------------------------------------------------------------------------
        Sample source code for  HRIT Data

        Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

        Disclaimer:
                MSC does not guarantee regarding the correctness, accuracy, reliability,
                or any other aspect regarding use of these sample codes.

        Detail of HRIT data:
                Please visit the MSC web site and refer to the document,
                "JMA HRIT Mission Specific Implementation (Issue 1.2, 1 January,2003)".

                MSC website:
                https://www.data.jma.go.jp/mscweb/en/index.html
                https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/sample_hrit.html

                HRIT data:
                https://www.data.jma.go.jp/mscweb/en/operation/fig/HRIT/JMA_HRIT_Issue1.2.pdf

        History
                March,   2015  First release
		June,	 2021  Version 2021-06
			       Fixed bug in function  getCalTable() function(hrit_read.c)

---------------------------------------------------------------------------- */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<math.h>

# include "hrit.h"

static int cmpint(const void *a,const void *b);
static int getCalTable(SpHritFile *info);
static int getCompTable(SpHritFile *info);
static int getObsTimeTable(SpHritFile *info);
static void getval(char *str,int *ival,float *fval,double *dval);

static int hritGetComp(SpHritFile *info,float ll,float *cmpCoff,float *cmpLoff);
static void getImgQual(SpHritFile *info);
static int getCpuEndian(void);
/* ----------------------------------------------------------------------------
   hrit_read_header()
   ----------------------------------------------------------------------------*/
int hrit_read_header(SpHritFile *info,const char *fileName){
	char *FN="spHritOpenFile()";
	int rtCode;
    int ii;
    char *cPtr;

	/* Initialize */
	info->fileName=strdup(fileName);
    info->startLineNo=-1;
    info->endLineNo=-1;
    info->nLine=-1;
    info->nPixel=-1;
    info->diffPix=info->diffLin=0;
    info->ch=-1;
    info->elem=SP_HRIT_NOELEM;
    info->fp=NULL;
    info->cpuEndian=getCpuEndian();

	/* Alloc Memory for Header */
    info->prim=(SpHritPrimary *)calloc(1,sizeof(SpHritPrimary));
    info->str=(SpHritImgStruct *)calloc(1,sizeof(SpHritImgStruct));
    info->nav=(SpHritNav *)calloc(1,sizeof(SpHritNav));
    info->datfunc=(SpHritDataFunc *)calloc(1,sizeof(SpHritDataFunc));
    info->annt=(SpHritAnnt *)calloc(1,sizeof(SpHritAnnt));
    info->stamp=(SpHritTimeStamp *)calloc(1,sizeof(SpHritTimeStamp));
    info->seg=(SpHritImgSegmentId *)calloc(1,sizeof(SpHritImgSegmentId));
    info->compinfo=(SpHritImgCompInfo *)calloc(1,sizeof(SpHritImgCompInfo));
    info->obstime=(SpHritImgObsTime *)calloc(1,sizeof(SpHritImgObsTime));
    info->qual=(SpHritQualityInfo *)calloc(1,sizeof(SpHritQualityInfo));

    /* Alloc Memory */
    info->calib=(SpHritCalib *)calloc(1,sizeof(SpHritCalib));
    info->comp=(SpHritComp *)calloc(1,sizeof(SpHritComp));
    info->ot=(SpHritObsTime *)calloc(1,sizeof(SpHritObsTime));
    info->proj=(SpHritProj *)calloc(1,sizeof(SpHritProj));

    /* allocate check */
    if(info->prim==NULL || info->str==NULL
        || info->nav==NULL || info->datfunc==NULL
        || info->annt==NULL || info->stamp==NULL
        || info->seg==NULL || info->compinfo==NULL
        || info->obstime==NULL || info->qual==NULL
        || info->calib==NULL || info->comp==NULL
        || info->ot==NULL || info->proj==NULL)
        {
        fprintf(stderr,"%s : Can't Alloc Memroy\n",FN);
        return(SP_HRIT_MEM);
        }

    /* Open HRIT File */
    if(NULL==(info->fp=fopen(info->fileName,"rb")))
        {
        fprintf(stderr,"%s : Can't Open File [%s] \n",FN,info->fileName);
        return(SP_HRIT_FOPEN);
        }
    /********************
       Read Header
     *********************/

    /* #0 Primary Header */
    if(1>fread(&info->prim->hdrType,1,1,info->fp))  { return(SP_HRIT_FREAD); }
    if(1>fread(&info->prim->recLen,2,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(1>fread(&info->prim->typeCode,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->prim->hdrLen,4,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(1>fread(&info->prim->datLen[0],4,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(1>fread(&info->prim->datLen[1],4,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->prim->recLen,2,1);
        spHritSwapBytes(&info->prim->hdrLen,4,1);
    /*  spHritSwapBytes(&info->prim->datLen[0],8,1); */ /* 2017.01 fixed bug */
        spHritSwapBytes(&info->prim->datLen[0],4,1);
        spHritSwapBytes(&info->prim->datLen[1],4,1);
        }
    info->prim->fDatLen=info->prim->datLen[1]+info->prim->datLen[0]*pow(2,32);
    /* #1 Image Structure */
    if(1>fread(&info->str->hdrType,1,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(1>fread(&info->str->recLen,2,1,info->fp))    { return(SP_HRIT_FREAD); }
    if(1>fread(&info->str->bitPix,1,1,info->fp))    { return(SP_HRIT_FREAD); }
    if(1>fread(&info->str->nPix,2,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(1>fread(&info->str->nLin,2,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(1>fread(&info->str->comp,1,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->str->recLen,2,1);
        spHritSwapBytes(&info->str->nPix,2,1);
        spHritSwapBytes(&info->str->nLin,2,1);
        }
    /* #2 Navigation */
    if(1>fread(&info->nav->hdrType,1,1,info->fp))   { return(SP_HRIT_FREAD); }
    if(1>fread(&info->nav->recLen,2,1,info->fp))    { return(SP_HRIT_FREAD); }
    if(32>fread(info->nav->projName,1,32,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->nav->cfac,4,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(1>fread(&info->nav->lfac,4,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(1>fread(&info->nav->coff,4,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(1>fread(&info->nav->loff,4,1,info->fp))      { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->nav->recLen,2,1);
        spHritSwapBytes(&info->nav->cfac,4,1);
        spHritSwapBytes(&info->nav->lfac,4,1);
        spHritSwapBytes(&info->nav->coff,4,1);
        spHritSwapBytes(&info->nav->loff,4,1);
        }
    /* #3 Image Data Function */
    if(1>fread(&info->datfunc->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->datfunc->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->datfunc->recLen,2,1);
        }
    info->datfunc->datDef=(char *)calloc(1,info->datfunc->recLen-3+1);
    if(info->datfunc->datDef==NULL) { return(SP_HRIT_MEM); }
    if(1>fread(info->datfunc->datDef,info->datfunc->recLen-3,1,info->fp))
        { return(SP_HRIT_FREAD); }
    /* #4 Annotation */
    if(1>fread(&info->annt->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->annt->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->annt->recLen,2,1);
        }
    info->annt->annt=(char *)calloc(1,info->annt->recLen-3+1);
    if(info->annt->annt==NULL) { return(SP_HRIT_MEM); }
    if(1>fread(info->annt->annt,info->annt->recLen-3,1,info->fp)) { return(SP_HRIT_FREAD); }
    /* #5 TimeStamp */
    if(1>fread(&info->stamp->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->stamp->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->stamp->cdsP,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->stamp->cdsTD,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->stamp->cdsTS,4,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->stamp->recLen,2,1);
        spHritSwapBytes(&info->stamp->cdsTD,2,1);
        spHritSwapBytes(&info->stamp->cdsTS,4,1);
        }
    /* #128 Image Segmentation Identification */
    if(1>fread(&info->seg->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->seg->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->seg->segSeqNo,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->seg->totalSegNo,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->seg->segLineNo,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->seg->recLen,2,1);
        spHritSwapBytes(&info->seg->segLineNo,2,1);
        }
    /* #130 Image Compensation Information Header */
    if(1>fread(&info->compinfo->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->compinfo->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->compinfo->recLen,2,1);
        }
    info->compinfo->compInfo=(char *)calloc(1,info->compinfo->recLen-3+1);
    if(info->compinfo->compInfo==NULL)  { return(SP_HRIT_MEM); }
    if(1>fread(info->compinfo->compInfo,info->compinfo->recLen-3,1,info->fp))
        { return(SP_HRIT_FREAD); }
    /* #131 Image Observation Time */
    if(1>fread(&info->obstime->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->obstime->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->obstime->recLen,2,1);
        }
    info->obstime->obsTime=(char *)calloc(1,info->obstime->recLen-3+1);
    if(info->obstime->obsTime==NULL)  { return(SP_HRIT_MEM); }
    if(1>fread(info->obstime->obsTime,info->obstime->recLen-3,1,info->fp))
        { return(SP_HRIT_FREAD); }
    /* #132 Image Quality Information */
    if(1>fread(&info->qual->hdrType,1,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(1>fread(&info->qual->recLen,2,1,info->fp)) { return(SP_HRIT_FREAD); }
    if(info->cpuEndian==SP_HRIT_LITTLE)
        {
        spHritSwapBytes(&info->qual->recLen,2,1);
        }
    info->qual->qInfo=(char *)calloc(1,info->qual->recLen-3+1);
    if(info->qual->qInfo==NULL)  { return(SP_HRIT_MEM); }
    if(1>fread(info->qual->qInfo,info->qual->recLen-3,1,info->fp))
        { return(SP_HRIT_FREAD); }

    /**********************
       Set Parameters
     ***********************/
    /* Calibration Parameters */
    if(SP_HRIT_NORMAL!=(rtCode=getCalTable(info))) { return(rtCode); }
    /* Compensation Parameters */
    if(SP_HRIT_NORMAL!=(rtCode=getCompTable(info))) { return(rtCode); }
    /* Observation Time Parameters */
    if(SP_HRIT_NORMAL!=(rtCode=getObsTimeTable(info))) { return(rtCode); }

    /* Basic Information */
    info->nLine=info->str->nLin;
    info->nPixel=info->str->nPix;
    info->startLineNo=info->seg->segLineNo;
    info->endLineNo=info->startLineNo+info->nLine-1;
    info->nFrameLine=info->endLineNo;

    /* Alloc Memory for Data Array */
    #if SP_HRIT_SMALL_MEM == 0
        info->lineData=(unsigned short **)calloc(info->nLine,sizeof(unsigned short *));
        if(info->lineData==NULL) { return(SP_HRIT_MEM); }
    #endif

    /* Error Pixel Rate */
    info->imgQual=(double *)calloc(sizeof(double),info->nLine);
    if(info->imgQual==NULL)
        {
        return(SP_HRIT_MEM);
        }
    getImgQual(info);

    /* Projection */
    if(NULL!=(cPtr=strchr(info->nav->projName,'(')))
        {
        cPtr++;
        info->proj->subLon=atof(cPtr);
        }
    /* Compensation Table */
    info->cmpCoff=(float *)malloc(sizeof(float)*info->nLine);
    info->cmpLoff=(float *)malloc(sizeof(float)*info->nLine);
    if(info->cmpCoff==NULL || info->cmpLoff==NULL)
        {
        fprintf(stderr,"%s : Can't Alloc Memory for Compensation Table \n",FN);
        return(SP_HRIT_MEM);
        }
    for(ii=0;ii<info->nLine;ii++)
        {
        if(SP_HRIT_NORMAL !=
            hritGetComp(info,info->startLineNo+ii,&info->cmpCoff[ii],&info->cmpLoff[ii]))
            {
            info->cmpCoff[ii]=info->nav->coff;
            info->cmpLoff[ii]=info->nav->loff;
            }
        }
	return(0);
}

/* ----------------------------------------------------------------------------
	Close HRIT File and Free Memory
   ----------------------------------------------------------------------------*/
int hrit_free(SpHritFile *info){
    int ii;

    /* Close File */
    if(info->fp!=NULL) { fclose(info->fp); }

    /* Free Memory */
    free(info->fileName);
    free(info->datfunc->datDef);
    free(info->annt->annt);
    free(info->compinfo->compInfo);
    free(info->obstime->obsTime);
    free(info->prim);
    free(info->str);
    free(info->nav);
    free(info->datfunc);
    free(info->annt);
    free(info->stamp);
    free(info->seg);
    free(info->compinfo);
    free(info->obstime);
    free(info->qual);

    /* Free Memory */
    free(info->calib->calTbl);
    free(info->calib);
    free(info->comp->compTbl);
    free(info->comp);
    free(info->ot->otTbl);
    free(info->ot);
    free(info->proj);
    free(info->cmpCoff);
    free(info->cmpLoff);
    free(info->imgQual);

    /* Free Memory for Data Array */
    #if SP_HRIT_SMALL_MEM == 0
        for(ii=0;ii<info->nLine;ii++)
            {
            free(info->lineData[ii]);
            }
        free(info->lineData);
    #endif

    /* Free Memory */
    free(info); info=NULL;

    return(0);
}

/* ----------------------------------------------------------------------------
   hrit_getdata_by_pixlin()
   ----------------------------------------------------------------------------*/
int hrit_getdata_by_pixlin(SpHritFile *header,FILE *fp, float hPix,float hLin,
	unsigned short *sout){

	float  pShift,lShift;
	int    ii;

    // init
	*sout=SP_HRIT_INVALID;

	// shift correction
	ii = (int)(hLin + 0.5) - header->startLineNo;
	if(ii < 0 ){
		ii = 0;
	}else if (header->nLine -1 < ii){
		ii = header->nLine -1;
	}
	lShift = header->nav->loff - header->cmpLoff[ii] ;
	pShift = header->nav->coff - header->cmpCoff[ii] ;
	hLin = hLin - lShift;
	hPix = hPix - pShift;

	// Nearest Neighbor
	int ll = (int)(hLin + 0.5) - header->startLineNo;
	int pp = (int)(hPix + 0.5) -1;

	// check ll and pp
	if(ll < 0 || header->nLine < ll){
		return(SP_HRIT_FREAD);
	}
	if(pp < 0 || header->nPixel < pp){
		return(SP_HRIT_FREAD);
	}

	// read data
	unsigned long seek_pt;
    seek_pt = header->prim->hdrLen
                    + (ll * header->str->nPix + pp ) * sizeof(unsigned short);
    if(seek_pt > header->prim->hdrLen + (int)header->prim->fDatLen){
        return(SP_HRIT_FREAD);
    }
    fseek(fp,seek_pt,SEEK_SET);
    fread(sout,sizeof(unsigned short), 1,header->fp);

	/* byte swap */
	if(getCpuEndian() == SP_HRIT_LITTLE ){
		spHritSwapBytes(sout,sizeof(unsigned short),1);
	}

	return(0);
}

/* ----------------------------------------------------------------------------
   ----------------------------------------------------------------------------*/
int hrit_radiace_to_tbb(){

	return(0);
}

/* ----------------------------------------------------------------------------
   ----------------------------------------------------------------------------*/
void spHritSwapBytes(void *buf,int size,int nData)
    {
    char *ba,*bb,*buf2=buf;

    while(nData--)
        {
        bb=(ba=buf2)+size-1;
        do
            {
            char a;
            a   = *ba;
            *ba = *bb;
            *bb =  a;
            }while(++ba<--bb);
        buf2 += size;
        }
    }
/* ----------------------------------------------------------------------------
 * getCalTable()
   ----------------------------------------------------------------------------*/
static int getCalTable(SpHritFile *info)
    {
    char *FN="getCalTable()";
    int nLet=0;
    int ii;
    char str[16];

    /* number of channel */
    if(NULL!=strstr(info->annt->annt,"VIS") || NULL!=strstr(info->annt->annt,"vis")) {
        info->ch=0;
    }else if(NULL!=strstr(info->annt->annt,"B03") || NULL!=strstr(info->annt->annt,"b03")){
        info->ch=0;
    }else if(NULL!=strstr(info->annt->annt,"B07") || NULL!=strstr(info->annt->annt,"b07")){
        info->ch=4;
    }else if(NULL!=strstr(info->annt->annt,"B08") || NULL!=strstr(info->annt->annt,"b08")){
        info->ch=3;
    }else if(NULL!=strstr(info->annt->annt,"B13") || NULL!=strstr(info->annt->annt,"b13")){
        info->ch=1;
    }else if(NULL!=strstr(info->annt->annt,"B15") || NULL!=strstr(info->annt->annt,"b15")){
        info->ch=2;
    }else if(NULL!=strstr(info->annt->annt,"B01") || NULL!=strstr(info->annt->annt,"b01")){
        info->ch=5;
    }else if(NULL!=strstr(info->annt->annt,"B02") || NULL!=strstr(info->annt->annt,"b02")){
        info->ch=6;
    }else if(NULL!=strstr(info->annt->annt,"B04") || NULL!=strstr(info->annt->annt,"b04")){
        info->ch=7;
    }else if(NULL!=strstr(info->annt->annt,"B05") || NULL!=strstr(info->annt->annt,"b05")){
        info->ch=8;
    }else if(NULL!=strstr(info->annt->annt,"B06") || NULL!=strstr(info->annt->annt,"b06")){
        info->ch=9;
    }else if(NULL!=strstr(info->annt->annt,"B09") || NULL!=strstr(info->annt->annt,"b09")){
        info->ch=10;
    }else if(NULL!=strstr(info->annt->annt,"B10") || NULL!=strstr(info->annt->annt,"b10")){
        info->ch=11;
    }else if(NULL!=strstr(info->annt->annt,"B11") || NULL!=strstr(info->annt->annt,"b11")){
        info->ch=12;
    }else if(NULL!=strstr(info->annt->annt,"B12") || NULL!=strstr(info->annt->annt,"b12")){
        info->ch=13;
    }else if(NULL!=strstr(info->annt->annt,"B14") || NULL!=strstr(info->annt->annt,"b14")){
        info->ch=14;
    }else if(NULL!=strstr(info->annt->annt,"B16") || NULL!=strstr(info->annt->annt,"b16")){
        info->ch=15;
    } else {
        for(ii=1;ii<=4;ii++)
            {
            sprintf(str,"IR%d",ii);
            if(NULL!=strstr(info->annt->annt,str))
                {
                info->ch=ii;
                break;
                }
            sprintf(str,"ir%d",ii);
            if(NULL!=strstr(info->annt->annt,str))
                {
                info->ch=ii;
                break;
                }
            }
        }
    /* For Calibration Table */
    info->calib->nTbl=0;
    info->calib->calTbl=NULL;
    for(ii=0;ii<info->datfunc->recLen-3;ii++)
        {
        if(info->datfunc->datDef[ii]==0xd)
            {
            /* skip $HALFTONE,_NAME,_UNIT */
            if(0==isdigit((int)str[0]))  { nLet=0; continue; }

            /* Terminate */
            str[nLet]='\0'; nLet=0;

            /* Alloc Memory */
            info->calib->calTbl = (SpHritCalTable *)
                realloc(info->calib->calTbl,(info->calib->nTbl+1)*sizeof(SpHritCalTable));
            if(info->calib->calTbl==NULL)
                {
                fprintf(stderr,"%s : Can't Alloc Memory to Make Calibration Table \n",FN);
                return(SP_HRIT_MEM);
                }
            info->calib->calTbl[info->calib->nTbl].level=0;
            info->calib->calTbl[info->calib->nTbl].phys=0;

            /* Set Level and Physical Value */
            getval(str,&info->calib->calTbl[info->calib->nTbl].level,
                &info->calib->calTbl[info->calib->nTbl].phys,NULL);

            /* Albedo (0-100) -> (0-1) */
	    if(info->ch==0 || info->ch==5 || info->ch==6 || info->ch==7 || info->ch==8 || info->ch==9) /* 2021.06 added */
		{ 
		info->calib->calTbl[info->calib->nTbl].phys/=100;
		}
            /* Counting */
            info->calib->nTbl++;
            }
        else
            {
            /* Get Letters */
            str[nLet]=info->datfunc->datDef[ii];
            nLet++;
            }
        }
    /* Sort in Level */
    qsort((SpHritCalTable *)info->calib->calTbl,info->calib->nTbl,sizeof(SpHritCalTable),cmpint);
    /* Number of Level */
    info->calib->nLevel=info->calib->calTbl[info->calib->nTbl-1].level+1;
    if(info->calib->nLevel==65536)
        {
           info->calib->nLevel = info->calib->calTbl[info->calib->nTbl-2].level +1;
        }

	// make table
	info->calib_table = (float *)calloc(info->calib->nLevel,sizeof(float));
	int level;
	for(level=0;level<info->calib->nLevel;level++){
		if(level < info->calib->calTbl[0].level){
		// 0
			info->calib_table[level] = info->calib->calTbl[0].phys;
		}else if(level > info->calib->calTbl[info->calib->nTbl-1].level){
		// max
			info->calib_table[level] = info->calib->calTbl[info->calib->nTbl-1].phys;
		}else{
			for(ii=0;ii<info->calib->nTbl-1;ii++){
				if(level == info->calib->calTbl[ii].level){
					info->calib_table[level] = info->calib->calTbl[ii].phys;
					break;
				}else if( info->calib->calTbl[ii].level < level &&
						  level <info->calib->calTbl[ii+1].level    ){
					info->calib_table[level] =
						(info->calib->calTbl[ii].phys-info->calib->calTbl[ii+1].phys) /
						/* --------------------------------------------------------*/
						(info->calib->calTbl[ii].level-info->calib->calTbl[ii+1].level)
						* (level-info->calib->calTbl[ii+1].level)
						+ info->calib->calTbl[ii+1].phys;
				}
			}
		}
	}
	return(SP_HRIT_NORMAL);
}
/* ----------------------------------------------------------------------------
   Compensation Table
   Return  SP_HRIT_NORMAL : Successs
          !SP_HRIT_NORMAL : Failure
   ----------------------------------------------------------------------------*/
static int getCompTable(SpHritFile *info)
    {
    int ii;
    char str[32];
    int nLet=0;
    short isFind=0;

    info->comp->nLine=0;
    info->comp->compTbl=NULL;
    for(ii=0;ii<info->compinfo->recLen-3;ii++)
        {
        if(info->compinfo->compInfo[ii]==0xd)
            {
            /* Terminate */
            str[nLet]='\0'; nLet=0;

            /* Alloc Memory for Sorting */
            info->comp->compTbl = (SpHritCompTable *)
                realloc(info->comp->compTbl,(info->comp->nLine+1)*sizeof(SpHritCompTable));
            if(info->comp->compTbl==NULL)
                {
                return(SP_HRIT_MEM);
                }
            if(isFind==0)
                {
                info->comp->compTbl[info->comp->nLine].line=0;
                info->comp->compTbl[info->comp->nLine].coff=0;
                info->comp->compTbl[info->comp->nLine].loff=0;
                }
            /* Set Value */
            if(0==strncmp(str,"LINE",4))
                {
                isFind++;
                getval(str,&info->comp->compTbl[info->comp->nLine].line,NULL,NULL);
                }
            else if(0==strncmp(str,"COFF",4))
                {
                isFind++;
                getval(str,NULL,&info->comp->compTbl[info->comp->nLine].coff,NULL);
                }
            else if(0==strncmp(str,"LOFF",4))
                {
                isFind++;
                getval(str,NULL,&info->comp->compTbl[info->comp->nLine].loff,NULL);
                }
            if(isFind==3)
                {
                info->comp->nLine++;
                isFind=0;
                }
            }
        else
            {
            /* Get Letters */
            str[nLet]=info->compinfo->compInfo[ii];
            nLet++;
            }
        }
    /* Sort in Level */
    qsort((SpHritCompTable *)info->comp->compTbl,info->comp->nLine,sizeof(SpHritCompTable),cmpint);
    return(SP_HRIT_NORMAL);
    }

/* ----------------------------------------------------------------------------
   Observation Time Table
   ----------------------------------------------------------------------------*/
static int getObsTimeTable(SpHritFile *info)
    {
    int ii;
    char str[32];
    int nLet=0;
    short isFind=0;

    info->ot->nLine=0;
    info->ot->otTbl=NULL;
    for(ii=0;ii<info->obstime->recLen-3;ii++)
        {
        if(info->obstime->obsTime[ii]==0xd)
            {
            /* Terminate */
            str[nLet]='\0'; nLet=0;

            /* Alloc Memory for Sorting */
            info->ot->otTbl = (SpHritObsTimeTable *)
                realloc(info->ot->otTbl,(info->ot->nLine+1)*sizeof(SpHritObsTimeTable));
            if(info->ot->otTbl==NULL)
                {
                return(SP_HRIT_MEM);
                }
            if(isFind==0)
                {
                info->ot->otTbl[info->ot->nLine].line=0;
                info->ot->otTbl[info->ot->nLine].mjd=0;
                }
            /* Set Value */
            if(0==strncmp(str,"LINE",4))
                {
                isFind++;
                getval(str,&info->ot->otTbl[info->ot->nLine].line,NULL,NULL);
                }
            else if(0==strncmp(str,"TIME",4))
                {
                isFind++;
                getval(str,NULL,NULL,&info->ot->otTbl[info->ot->nLine].mjd);
                }
            if(isFind==2)
                {
                info->ot->nLine++;
                isFind=0;
                }
            }
        else
            {
            /* Get Letters */
            str[nLet]=info->obstime->obsTime[ii];
            nLet++;
            }
        }
    /* Sort in Level */
    qsort((SpHritCompTable *)info->ot->otTbl,info->ot->nLine,sizeof(SpHritObsTimeTable),cmpint);
    return(SP_HRIT_NORMAL);
    }

/* ----------------------------------------------------------------------------
   Image Quality
   ----------------------------------------------------------------------------*/
static void getImgQual(SpHritFile *info)
    {
    int ii;
    char str[32];
    int nLet=0;
    short isFind=0;
    int lineNo;

    for(ii=0;ii<info->qual->recLen-3;ii++)
        {
        if(info->qual->qInfo[ii]==0xd)
            {
            /* Termination */
            str[nLet]='\0'; nLet=0;

            /* Set Value */
            if(0==strncmp(str,"LINE",4))
                {
                isFind++;
                getval(str,&lineNo,NULL,NULL);
                }
            else if(0==strncmp(str,"ERROR",4))
                {
                isFind++;
                getval(str,NULL,NULL,&(info->imgQual[lineNo-info->startLineNo]));
                }
            if(isFind==2)
                {
                isFind=0;
                }
            }
        else
            {
            /* Get Letters */
            str[nLet]=info->qual->qInfo[ii];
            nLet++;
            }
        }
    }



/* ----------------------------------------------------------------------------
   Compensation
    Return  :  SP_HRIT_NORMAL : Success
              !SP_HRIT_NORMAL : Failure
   ----------------------------------------------------------------------------*/
static int hritGetComp(SpHritFile *info,float ll,float *cmpCoff,float *cmpLoff)
    {
    int ii;
    int isFind=0;

    /* Too Small */
    if(ll<info->comp->compTbl[0].line)
        {
        *cmpCoff=info->comp->compTbl[0].coff;
        *cmpLoff=info->comp->compTbl[0].loff;
        return(SP_HRIT_NORMAL);
        }
    /* Too Big */
    else if(ll>info->comp->compTbl[info->comp->nLine-1].line)
        {
        *cmpCoff=info->comp->compTbl[info->comp->nLine-1].coff;
        *cmpLoff=info->comp->compTbl[info->comp->nLine-1].loff;
        return(SP_HRIT_NORMAL);
        }

    /* Search */
    for(ii=0;ii<info->comp->nLine;ii++)
        {
        /* ll */
        if(info->comp->compTbl[ii].line==ll)
            {
            *cmpCoff=info->comp->compTbl[ii].coff;
            *cmpLoff=info->comp->compTbl[ii].loff;
            return(SP_HRIT_NORMAL);
            }
        /* ll+1 */
        if(ll<info->comp->compTbl[ii].line)
            {
            isFind=1;
            break;
            }
        }

    /* Interpolation */
    if(isFind==1)
        {
        *cmpCoff=
            (info->comp->compTbl[ii].coff-info->comp->compTbl[ii-1].coff)
                                        /
            ((float)info->comp->compTbl[ii].line-(float)info->comp->compTbl[ii-1].line)
            * (ll-(float)info->comp->compTbl[ii-1].line)+info->comp->compTbl[ii-1].coff;
        *cmpLoff=
            (info->comp->compTbl[ii].loff-info->comp->compTbl[ii-1].loff)
                                        /
            ((float)info->comp->compTbl[ii].line-(float)info->comp->compTbl[ii-1].line)
            * (ll-(float)info->comp->compTbl[ii-1].line)+info->comp->compTbl[ii-1].loff;
        return(SP_HRIT_NORMAL);
        }

    return(!SP_HRIT_NORMAL);
    }
/* ----------------------------------------------------------------------------
   ----------------------------------------------------------------------------*/



/* ----------------------------------------------------------------------------
   ----------------------------------------------------------------------------*/
static int getCpuEndian(void)
    {
    int i=1;

    if( *((char *)&i) )
        {
        return(0);
        }
    else if( *( (char *)&i + (sizeof(int) -1) ) )
        {
        return(1);
        }
    else
        {
        return(-1);
        }
    }
/*
 *     Convert Letters into Numerical Value
 *     */
static void getval(char *str,int *ival,float *fval,double *dval)
    {
    char *ctmp;

    /* Start with Number */
    if(0!=isdigit((int)str[0]))
        {
        *ival=atoi(str);
        ctmp=strstr(str,":="); ctmp+=2;
        *fval=atof(ctmp);
        }
    /* LINE */
    else if(0==strncmp(str,"LINE",4))
        {
        ctmp=strstr(str,":="); ctmp+=2;
        *ival=atoi(ctmp);
        }
    /* COFF or LOFF */
    else if(0==strncmp(str,"COFF",4) || 0==strncmp(str,"LOFF",4))
        {
        ctmp=strstr(str,":="); ctmp+=2;
        *fval=atof(ctmp);
        }
    else if(0==strncmp(str,"TIME",4))
        {
        ctmp=strstr(str,":="); ctmp+=2;
        *dval=atof(ctmp);
        }
    /* QUAL */
    else if(0==strncmp(str,"ERROR",5))
        {
        ctmp=strstr(str,":="); ctmp+=2;
        *dval=atof(ctmp);
        }
    }
static int cmpint(const void *a,const void *b)
    {
    int ret;

    ret=*(int *)a-*(int *)b;
    return(ret);
    }
