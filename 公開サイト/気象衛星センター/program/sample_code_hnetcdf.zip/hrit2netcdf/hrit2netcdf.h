
# define  NORMAL_END        0
# define  ERROR_ARG         1
# define  ERROR_FILE_OPEN   2
# define  ERROR_CALLOCATE   3
# define  ERROR_READ_HEADER 4
# define  ERROR_INFO        5
# define  ERROR_READ_DATA   6
# define  ERROR_PARAMETER   7
# define  ERROR_MAKE_HEADER 8
# define  ERROR_MAKE_DATA   9
# define  ERROR_WRITE       10

