/* ----------------------------------------------------------------------------
	Sample source code for Himawari Satandard Data

	Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

	Disclaimer:
		MSC does not guarantee regarding the correctness, accuracy, reliability,
		or any other aspect regarding use of these sample codes.

	Detail of Himawari Standard Format:
		For data structure of Himawari Standard Format, prelese refer to MSC
		Website and Himawari Standard Data User's Guide.

		MSC Website
		https://www.data.jma.go.jp/mscweb/en/index.html

		Himawari Standard Data User's Guide
		https://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en_v13.pdf

	History
		March,   2015 First release
		May,     2015 Change for version 1.2
        June,    2015 Version 2015-06
                      Changed the default "byte order" (downsample.h)
                      Fixed bug fixed of hisd_read_header() (hisd_read.c)
---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hisd.h"
# include "downsample.h"

/* ---------------------------------------------------------------------------
 *   downsample HISD file
 *   	2km   to 4km
 *   	1km   to 2km
 *   	0.5km to 1km
 ----------------------------------------------------------------------------*/
int main(int argc, char *argv[]){
	HisdHeader	*hisd;
	unsigned short	*hisd_data_o;
	unsigned short	*hisd_data_n;
	FILE		*fp;
	FILE		*fo;
	char		*InFile;
	unsigned long n_size;
	char		*fileName;

	// -----------------------------------------------------------------------
	// 1 prepare
	// -----------------------------------------------------------------------
	if(argc != 2){
		char *cPtr=strrchr(argv[0],'/');
		if(cPtr==NULL)
			{
			cPtr=argv[0];
			}
		else
			{
			cPtr++;
			}
		fprintf(stderr,"usage : %s HISD_FILE\n",cPtr);
		return(ERROR_ARG);
	}
	InFile = argv[1];
	if(NULL==(fp=fopen(InFile,"rb"))){
		fprintf(stderr,"file open error\n");
		return(ERROR_FILE_OPEN);
	}
	if(NULL == (fileName = strrchr(InFile,'/'))){
		fileName=InFile;
	}else{
		fileName++;
	}
	// -----------------------------------------------------------------------
	// 2 read hisd haeder
	// -----------------------------------------------------------------------
	hisd = (HisdHeader *)calloc(1,sizeof(HisdHeader));
	if(hisd == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if(NORMAL_END != hisd_read_header(hisd,fp)){
		fprintf(stderr,"hisd_read_header() : errorr\n");
		return(ERROR_READ_HEADER);
	}
	// -----------------------------------------------------------------------
	// 3 read hisd data block
	// -----------------------------------------------------------------------
	n_size = hisd->data->nPix * hisd->data->nLin;
	hisd_data_o = (unsigned short *)calloc(n_size,sizeof(unsigned short));
	if(hisd_data_o == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if( n_size > fread(hisd_data_o,sizeof(unsigned short),n_size,fp)){
		fprintf(stderr,"data read error\n");
		return(ERROR_READ_DATA);
	}
	// -----------------------------------------------------------------------
	// 4 byte swap
	// -----------------------------------------------------------------------
	if(byteOrder() != hisd->basic->byteOrder ){
		swapBytes(&hisd_data_o[0],sizeof(unsigned short),n_size);
	}
	// -----------------------------------------------------------------------
	// 5 make new hisd header
	// -----------------------------------------------------------------------
	HisdHeader *hisd_new;
	hisd_new = (HisdHeader *)calloc(1,sizeof(HisdHeader));
	if(0 != make_hisd_header(hisd,hisd_new)){
		fprintf(stderr,"make_hisd_header() : error\n");
		return(ERROR_MAKE_HEADER);
	}
	// -----------------------------------------------------------------------
	// 6 make new hisd data block
	// -----------------------------------------------------------------------
	n_size = hisd_new->data->nPix * hisd_new->data->nLin;
	hisd_data_n = (unsigned short *)calloc(n_size,sizeof(unsigned short));
	if(hisd_data_n == NULL){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	if(0 != make_hisd_data(hisd,hisd_new,hisd_data_o,hisd_data_n)){
		fprintf(stderr,"make_hisd_data() : error\n");
		return(ERROR_MAKE_DATA);
	}
	if(0 !=make_hisd_errorinfo(hisd_new,hisd_data_n)){
		fprintf(stderr,"make_hisd_errorinfo() : error\n");
		return(ERROR_MAKE_HEADER);
	}
	// -----------------------------------------------------------------------
	// 7 write hisd header
	// -----------------------------------------------------------------------
	fo=fopen(hisd_new->basic->fileName,"wb");
	if(fo == NULL){
		fprintf(stderr,"output file [%s] : open error\n",
			hisd_new->basic->fileName);
		return(ERROR_FILE_OPEN);
	}
	if(0 != write_hisd_header(hisd_new,fo,ENDIAN)){
		fprintf(stderr,"error : write_hrit_header()\n");
		return(ERROR_WRITE);
	}
	// -----------------------------------------------------------------------
	// 8 write data block
	// -----------------------------------------------------------------------
	if(0 != write_data(hisd_data_n,n_size,fo,ENDIAN)){
		fprintf(stderr,"error : write_hisd_dat\n");
		return(ERROR_WRITE);
	}
	printf("Input  File : %s\n",fileName);
	printf("Output File : %s\n",hisd_new->basic->fileName);
	// -----------------------------------------------------------------------
	// 9 end
	// -----------------------------------------------------------------------
	fclose(fo);
	fclose(fp);
	hisd_free(hisd);
	hisd_free(hisd_new);
	return(NORMAL_END);
}
